#############Imports#############
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , base64 , os , re , unicodedata , requests , time , string , sys , urllib , urllib2 , json , urlparse , datetime , zipfile , shutil
from resources . modules import client , control , tools , shortlinks
from datetime import date
import xml . etree . ElementTree as ElementTree
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = 'plugin.video.neptuneiptv'
iIiiiI1IiI1I1 = xbmcaddon . Addon ( id = IiII1IiiIiI1 )
o0OoOoOO00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'icon.png' ) )
I11i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'fanart.jpg' ) )
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
I11iIi1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'account.png' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'livetv.png' ) )
IiII = 'aHR0cDovL2dhemJob3kuY29t'
iI1Ii11111iIi = 'ODA='
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'catchup.png' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'vod.png' ) )
I1i1iiI1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'tv.png' ) )
iiIIIII1i1iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'settings.png' ) )
o0oO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'logout.png' ) )
oo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'search.png' ) )
o00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'current.png' ) )
Oo0oO0ooo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'allowed.png' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'user.png' ) )
i1oOOoo00O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'pass.png' ) )
i1111 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'clear.png' ) )
i11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'eas.png' ) )
I11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'speed.png' ) )
Oo0o0000o0o0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'meta.png' ) )
oOo0oooo00o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'xxx.png' ) )
oO0o0o0ooO0oO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'date.png' ) )
oo0o0O00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/icons' , 'status.png' ) )
if 68 - 68: o00oo . iI1 + OoOooOOOO
i11iiII = control . setting ( 'Username' )
I1iiiiI1iII = control . setting ( 'Password' )
if 20 - 20: I1 + i1Ii % o00O00O0O0O / ooO0O * oo
iii11iII = ( base64 . b64decode ( IiII ) )
i1I111I = ( base64 . b64decode ( iI1Ii11111iIi ) )
if 1 - 1: O0OOooO % IiIiIi . i1
ooOoOoo0O = '%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories' % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII )
OooO0 = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII )
II11iiii1Ii = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories' % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII )
OO0o = '%s:%s/panel_api.php?username=%s&password=%s' % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII )
Ooo = '%s:%s/%s/%s/%s/' % ( iii11iII , i1I111I , type , i11iiII , I1iiiiI1iII )
O0o0Oo = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series&cat_id=0' % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII )
if 78 - 78: iIii1I11I1II1 - o00O00O0O0O * ii1IiI1i + o00oo + ooO0O + ooO0O
I11I11i1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.neptuneiptv/resources/catchup' , 'guide.xml' ) )
ii11i1iIII = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.neptuneiptv/resources/catchup' , 'g' ) )
if 3 - 3: i1IIi / OOooo000oo0 % i1Ii * i11iIiiIii / O0 * i1Ii
III1ii1iII = xbmc . translatePath ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/advanced_settings' )
oo0oooooO0 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , 'advancedsettings.xml' ) )
if 19 - 19: i1Ii + IiIiIi
if 53 - 53: OoooooooOO . i1IIi
if 18 - 18: o00oo
def I1i1I1II ( ) :
 if i11iiII == "" :
  i1IiIiiI = I1I ( )
  oOO00oOO = OoOo ( )
  control . setSetting ( 'Username' , i1IiIiiI )
  control . setSetting ( 'Password' , oOO00oOO )
  xbmc . executebuiltin ( 'Container.Refresh' )
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( iii11iII , i1I111I , i1IiIiiI , oOO00oOO )
  iI = tools . OPEN_URL ( iI )
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories' % ( iii11iII , i1I111I , i1IiIiiI , oOO00oOO )
  iI = tools . OPEN_URL ( iI )
  if iI == "" :
   o00O = "Login Details Incorrect"
   OOO0OOO00oo = "Please Try Again"
   Iii111II = ""
   xbmcgui . Dialog ( ) . ok ( 'Attention' , o00O , OOO0OOO00oo , Iii111II )
   I1i1I1II ( )
  else :
   o00O = "Login Successful"
   OOO0OOO00oo = "Welcome to [B]Neptune[/B]!"
   Iii111II = ( '[B][COLOR red]%s[/COLOR][/B]' % i1IiIiiI )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , o00O , OOO0OOO00oo , Iii111II )
   iiii11I ( 'ADS2' , '' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   Ooo0OO0oOO ( )
 else :
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII )
  iI = tools . OPEN_URL ( iI )
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories' % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII )
  iI = tools . OPEN_URL ( iI )
  if not iI == "" :
   tools . addDir ( '[B][COLOR white]Account Information[/COLOR][/B]' , 'url' , 6 , I11iIi1I , I11i , '' )
   tools . addDir ( '[B][COLOR white]Live Channels[/COLOR][/B]' , 'live' , 1 , IiiIII111iI , I11i , '' )
   tools . addDir ( '[B][COLOR white]Movies[/COLOR][/B]' , 'url' , 11 , O0oo0OO0 , I11i , '' )
   tools . addDir ( '[B][COLOR white]TV Shows[/COLOR][/B]' , 'url' , 12 , I1i1iiI1 , I11i , '' )
   tools . addDir ( '[B][COLOR white]Catchup TV[/COLOR][/B]' , 'url' , 13 , i1i1II , I11i , '' )
   tools . addDir ( '[B][COLOR white]Tools[/COLOR][/B]' , 'url' , 16 , iiIIIII1i1iI , I11i , '' )
   tools . addDir ( '[B][COLOR white]Log Out[/COLOR][/B]' , 'LO' , 10 , o0oO0 , I11i , '' )
   if 50 - 50: OOooo000oo0
def Ooo0OO0oOO ( ) :
 tools . addDir ( 'Account Information' , 'url' , 6 , o0OoOoOO00 , I11i , '' )
 tools . addDir ( 'Live Channels' , 'live' , 1 , o0OoOoOO00 , I11i , '' )
 tools . addDir ( 'Movies' , 'url' , 11 , o0OoOoOO00 , I11i , '' )
 tools . addDir ( 'TV Shows' , 'url' , 12 , o0OoOoOO00 , I11i , '' )
 tools . addDir ( 'Catchup TV' , 'url' , 13 , o0OoOoOO00 , I11i , '' )
 tools . addDir ( 'Tools' , 'url' , 16 , o0OoOoOO00 , I11i , '' )
 tools . addDir ( 'Log Out' , 'LO' , 10 , o0OoOoOO00 , I11i , '' )
 if 34 - 34: OOooo000oo0 * II111iiii % ooO0O * IIIiiIIii - OOooo000oo0
def II1III ( url ) :
 if 19 - 19: OoOooOOOO % i1IIi % o00oo
 open = tools . OPEN_URL ( ooOoOoo0O )
 oo0OooOOo0 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for o0O in oo0OooOOo0 :
  O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
  O00oO = base64 . b64decode ( O00oO )
  I11i1I1I = tools . regex_from_to ( o0O , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
  if xbmcaddon . Addon ( ) . getSetting ( 'hidexxx' ) == 'true' :
   tools . addDir ( '%s' % O00oO , I11i1I1I , 2 , o0OoOoOO00 , I11i , '' )
  else :
   if not 'XXX' in O00oO :
    if not 'Adult' in O00oO :
     tools . addDir ( '%s' % O00oO , I11i1I1I , 2 , o0OoOoOO00 , I11i , '' )
     if 83 - 83: iI1 / IiIiIi
def iIIIIii1 ( url ) :
 open = tools . OPEN_URL ( url )
 oo0OooOOo0 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for o0O in oo0OooOOo0 :
  O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
  O00oO = base64 . b64decode ( O00oO )
  xbmc . log ( str ( O00oO ) )
  try :
   O00oO = re . sub ( '\[.*?min ' , '-' , O00oO )
  except :
   pass
  oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
  I11i1I1I = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
  O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
  if xbmcaddon . Addon ( ) . getSetting ( 'hidexxx' ) == 'true' :
   tools . addDir ( O00oO , I11i1I1I , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
  else :
   if not 'XXX' in O00oO :
    if not 'Adult' in O00oO :
     tools . addDir ( O00oO , I11i1I1I , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
     if 70 - 70: oo * i1 * i1Ii / o00O00O0O0O
def oO ( url ) :
 if url == "vod" :
  open = tools . OPEN_URL ( OooO0 )
 else :
  open = tools . OPEN_URL ( url )
 oo0OooOOo0 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for o0O in oo0OooOOo0 :
  if '<playlist_url>' in open :
   O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
   I11i1I1I = tools . regex_from_to ( o0O , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( O00oO ) ) . replace ( '?' , '' ) , I11i1I1I , 3 , o0OoOoOO00 , I11i , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
     O00oO = base64 . b64decode ( O00oO )
     oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
     O0OOO0OOoO0O = base64 . b64decode ( O0OOO0OOoO0O )
     OOoO0O00o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'PLOT:' , '\n' )
     iII = tools . regex_from_to ( O0OOO0OOoO0O , 'CAST:' , '\n' )
     o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'RATING:' , '\n' )
     ooOooo000oOO = tools . regex_from_to ( O0OOO0OOoO0O , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     ooOooo000oOO = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( ooOooo000oOO )
     Oo0oOOo = tools . regex_from_to ( O0OOO0OOoO0O , 'DURATION_SECS:' , '\n' )
     Oo0OoO00oOO0o = tools . regex_from_to ( O0OOO0OOoO0O , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( O00oO ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , oo000OO00Oo , I11i , OOoO0O00o0 , str ( ooOooo000oOO ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( iII ) . split ( ) , o0 , Oo0oOOo , Oo0OoO00oOO0o )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
   else :
    O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
    O00oO = base64 . b64decode ( O00oO )
    oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
    if xbmcaddon . Addon ( ) . getSetting ( 'hidexxx' ) == 'true' :
     tools . addDir ( O00oO , url , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
    else :
     if not 'XXX' in O00oO :
      if not 'Adult' in O00oO :
       tools . addDir ( O00oO , url , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 80 - 80: OoOooOOOO + I1 - I1 % ooO0O
 if 63 - 63: OOooo000oo0 - iI1 + O0 % i1Ii / iIii1I11I1II1 / o00oo
def O0o0O00Oo0o0 ( ) :
 O00O0oOO00O00 ( )
 if 11 - 11: oo . iI1
def O00O0oOO00O00 ( ) :
 open = tools . OPEN_URL ( OO0o )
 all = tools . regex_get_all ( open , '{"num' , 'direct' )
 for o0O in all :
  if '"tv_archive":1' in o0O :
   O00oO = tools . regex_from_to ( o0O , '"epg_channel_id":"' , '"' ) . replace ( '\/' , '/' )
   oo000OO00Oo = tools . regex_from_to ( o0O , '"stream_icon":"' , '"' ) . replace ( '\/' , '/' )
   id = tools . regex_from_to ( o0O , 'stream_id":"' , '"' )
   if not O00oO == "" :
    tools . addDir ( O00oO , 'url' , 14 , oo000OO00Oo , I11i , id )
    if 92 - 92: ooO0O . O0OOooO
    if 31 - 31: O0OOooO . IIIiiIIii / O0
def o000O0o ( name , description ) :
 iI1iII1 = 7
 if 86 - 86: I1
 OOoo0O = str ( datetime . datetime . now ( ) ) . replace ( '-' , '' ) . replace ( ':' , '' ) . replace ( ' ' , '' )
 Oo0ooOo0o = datetime . datetime . now ( ) - datetime . timedelta ( iI1iII1 )
 Ii1i1 = str ( Oo0ooOo0o )
 Ii1i1 = str ( Ii1i1 ) . replace ( '-' , '' ) . replace ( ':' , '' ) . replace ( ' ' , '' )
 iiIii = base64 . b64decode ( "JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmYWN0aW9uPWdldF9zaW1wbGVfZGF0YV90YWJsZSZzdHJlYW1faWQ9JXM=" ) % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII , description )
 ooo0O = tools . OPEN_URL ( iiIii )
 oOoO0o00OO0 = re . compile ( '"title":"(.+?)".+?"start":"(.+?)","end":"(.+?)","description":"(.+?)"' ) . findall ( ooo0O )
 for i1I1ii , I1i1I1II , oOOo0 , oo00O00oO in oOoO0o00OO0 :
  i1I1ii = base64 . b64decode ( i1I1ii )
  oo00O00oO = base64 . b64decode ( oo00O00oO )
  format = '%Y-%m-%d %H:%M:%S'
  try :
   iIiIIIi = dtdeep . strptime ( oOOo0 , format )
   ooo00OOOooO = dtdeep . strptime ( I1i1I1II , format )
  except :
   iIiIIIi = datetime . datetime ( * ( time . strptime ( oOOo0 , format ) [ 0 : 6 ] ) )
   ooo00OOOooO = datetime . datetime ( * ( time . strptime ( I1i1I1II , format ) [ 0 : 6 ] ) )
  O00OOOoOoo0O = iIiIIIi - ooo00OOOooO
  O000OOo00oo = time . mktime ( iIiIIIi . timetuple ( ) )
  oo0OOo = time . mktime ( ooo00OOOooO . timetuple ( ) )
  ooOOO00Ooo = int ( O000OOo00oo - oo0OOo ) / 60
  IiIIIi1iIi = I1i1I1II
  ooOOoooooo = str ( IiIIIi1iIi ) . replace ( '-' , '' ) . replace ( ':' , '' ) . replace ( ' ' , '' )
  II1I = I1i1I1II [ : - 3 ]
  O0i1II1Iiii1I11 = II1I
  II1I = str ( II1I ) . replace ( ' ' , ' - ' )
  I1i1I1II = str ( O0i1II1Iiii1I11 ) . replace ( ' ' , ':' )
  IIII = I1i1I1II [ : 13 ] + '-' + I1i1I1II [ 13 : ]
  iiIiI = IIII . replace ( '-:' , '-' )
  if ooOOoooooo > Ii1i1 :
   if ooOOoooooo < OOoo0O :
    o00oooO0Oo = base64 . b64decode ( "JXM6JXMvc3RyZWFtaW5nL3RpbWVzaGlmdC5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmc3RyZWFtPSVzJnN0YXJ0PQ==" ) % ( iii11iII , i1I111I , i11iiII , I1iiiiI1iII , description )
    o0O0OOO0Ooo = o00oooO0Oo + str ( iiIiI ) + "&duration=%s" % ( ooOOO00Ooo )
    iiIiII1 = "[B][COLOR white]%s[/COLOR][/B] - %s" % ( II1I , i1I1ii )
    tools . addDir ( iiIiII1 , o0O0OOO0Ooo , 4 , o0OoOoOO00 , I11i , oo00O00oO )
    if 86 - 86: IIIiiIIii - o00O00O0O0O - ii1IiI1i * ooO0O
    if 66 - 66: OoooooooOO + O0
def I1IiiI ( url , dest ) :
 IIi = xbmcgui . DialogProgress ( )
 IIi . create ( 'Fetching latest Catch Up' , "Fetching latest Catch Up..." , ' ' , ' ' )
 IIi . update ( 0 )
 i1Iii1i1I = time . time ( )
 urllib . urlretrieve ( url , dest , lambda OOoO00 , IiI111111IIII , i1Iiii111iI1iIi1 : OOO ( OOoO00 , IiI111111IIII , i1Iiii111iI1iIi1 , IIi , i1Iii1i1I ) )
 if 68 - 68: II111iiii + i1Ii
def OOO ( numblocks , blocksize , filesize , dp , start_time ) :
 try :
  I1I1I = min ( numblocks * blocksize * 100 / filesize , 100 )
  OoOO000 = float ( numblocks ) * blocksize / ( 1024 * 1024 )
  i1Ii11i1i = numblocks * blocksize / ( time . time ( ) - start_time )
  if i1Ii11i1i > 0 :
   o0oOOoo = ( filesize - numblocks * blocksize ) / i1Ii11i1i
  else :
   o0oOOoo = 0
  i1Ii11i1i = i1Ii11i1i / 1024
  oOo00O0oo00o0 = i1Ii11i1i / 1024
  ii = float ( filesize ) / ( 1024 * 1024 )
  OOooooO0Oo = '[COLOR white]%.02f MB of less than 5MB[/COLOR]' % ( OoOO000 )
  OO = '[COLOR white]Speed:  %.02f Mb/s ' % oOo00O0oo00o0 + '[/COLOR]'
  dp . update ( I1I1I , OOooooO0Oo , OO )
 except :
  I1I1I = 100
  dp . update ( I1I1I )
 if dp . iscanceled ( ) :
  iIiIIi1 = xbmcgui . Dialog ( )
  iIiIIi1 . ok ( "MyTV" , 'The download was cancelled.' )
  if 7 - 7: IiIiIi - i1 - OoOooOOOO + IiIiIi
  sys . exit ( )
  dp . close ( )
  if 26 - 26: o00O00O0O0O
def I11iiI1i1 ( url ) :
 I1i1Iiiii = OOo0oO00ooO00 ( )
 if not I1i1Iiiii :
  xbmc . executebuiltin ( "XBMC.Notification([COLOR orange][B]Search is Empty[/B][/COLOR],Aborting search,4000," + o0OoOoOO00 + ")" )
  return
 return oOO0O00oO0Ooo ( url , I1i1Iiiii )
 if 67 - 67: ii1IiI1i - I1
def oOO0O00oO0Ooo ( url , search = None ) :
 if 36 - 36: oo
 open = tools . OPEN_URL ( url )
 if 36 - 36: IiIiIi / O0 * i1 - I1 % iIii1I11I1II1 * OoOooOOOO
 oo0OooOOo0 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for o0O in oo0OooOOo0 :
  if '<playlist_url>' in open :
   O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
   O00oO = base64 . b64decode ( O00oO )
   I11i1I1I = tools . regex_from_to ( o0O , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   if 79 - 79: O0
   if search == None or ( search . lower ( ) in O00oO . lower ( ) ) :
    tools . addDir ( str ( O00oO ) . replace ( '?' , '' ) , I11i1I1I , 24 , o0OoOoOO00 , I11i , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
     O00oO = base64 . b64decode ( O00oO )
     oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
     O0OOO0OOoO0O = base64 . b64decode ( O0OOO0OOoO0O )
     OOoO0O00o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'PLOT:' , '\n' )
     iII = tools . regex_from_to ( O0OOO0OOoO0O , 'CAST:' , '\n' )
     o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'RATING:' , '\n' )
     ooOooo000oOO = tools . regex_from_to ( O0OOO0OOoO0O , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     ooOooo000oOO = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( ooOooo000oOO )
     Oo0oOOo = tools . regex_from_to ( O0OOO0OOoO0O , 'DURATION_SECS:' , '\n' )
     Oo0OoO00oOO0o = tools . regex_from_to ( O0OOO0OOoO0O , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( O00oO ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , oo000OO00Oo , I11i , OOoO0O00o0 , str ( ooOooo000oOO ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( iII ) . split ( ) , o0 , Oo0oOOo , Oo0OoO00oOO0o )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
   else :
    O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
    O00oO = base64 . b64decode ( O00oO )
    oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
    tools . addDir ( O00oO , url , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 78 - 78: iI1 + I1 - O0OOooO
 if 38 - 38: o00oo - OoOooOOOO + iIii1I11I1II1 / IIIiiIIii % i1
 if 57 - 57: ii1IiI1i / IiIiIi
def Ii1I1Ii ( url ) :
 if url == "seasons" :
  open = tools . OPEN_URL ( seasons_url )
 else :
  open = tools . OPEN_URL ( url )
 oo0OooOOo0 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for o0O in oo0OooOOo0 :
  if '<playlist_url>' in open :
   O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
   I11i1I1I = tools . regex_from_to ( o0O , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( O00oO ) ) . replace ( '?' , '' ) , I11i1I1I , 21 , o0OoOoOO00 , I11i , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
     O00oO = base64 . b64decode ( O00oO )
     oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
     O0OOO0OOoO0O = base64 . b64decode ( O0OOO0OOoO0O )
     OOoO0O00o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'PLOT:' , '\n' )
     iII = tools . regex_from_to ( O0OOO0OOoO0O , 'CAST:' , '\n' )
     o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'RATING:' , '\n' )
     ooOooo000oOO = tools . regex_from_to ( O0OOO0OOoO0O , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     ooOooo000oOO = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( ooOooo000oOO )
     Oo0oOOo = tools . regex_from_to ( O0OOO0OOoO0O , 'DURATION_SECS:' , '\n' )
     Oo0OoO00oOO0o = tools . regex_from_to ( O0OOO0OOoO0O , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( O00oO ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , oo000OO00Oo , I11i , OOoO0O00o0 , str ( ooOooo000oOO ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( iII ) . split ( ) , o0 , Oo0oOOo , Oo0OoO00oOO0o )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
   else :
    O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
    O00oO = base64 . b64decode ( O00oO )
    oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
    tools . addDir ( O00oO , url , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 69 - 69: OOooo000oo0 / o00oo . oo * O0OOooO % o00O00O0O0O - o00oo
 if 13 - 13: o00O00O0O0O . i11iIiiIii
 if 56 - 56: iI1 % O0 - OOooo000oo0
def O00o0OO0 ( url ) :
 open = tools . OPEN_URL ( url )
 if 35 - 35: OoOooOOOO % IiIiIi / O0OOooO + iIii1I11I1II1 . OoooooooOO . OOooo000oo0
 oo0OooOOo0 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for o0O in oo0OooOOo0 :
  if '<playlist_url>' in open :
   O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
   I11i1I1I = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( O00oO ) ) . replace ( '?' , '' ) , I11i1I1I , 22 , o0OoOoOO00 , I11i , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
     O00oO = base64 . b64decode ( O00oO )
     oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
     O0OOO0OOoO0O = base64 . b64decode ( O0OOO0OOoO0O )
     OOoO0O00o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'PLOT:' , '\n' )
     iII = tools . regex_from_to ( O0OOO0OOoO0O , 'CAST:' , '\n' )
     o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'RATING:' , '\n' )
     ooOooo000oOO = tools . regex_from_to ( O0OOO0OOoO0O , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     ooOooo000oOO = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( ooOooo000oOO )
     Oo0oOOo = tools . regex_from_to ( O0OOO0OOoO0O , 'DURATION_SECS:' , '\n' )
     Oo0OoO00oOO0o = tools . regex_from_to ( O0OOO0OOoO0O , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( O00oO ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , oo000OO00Oo , I11i , OOoO0O00o0 , str ( ooOooo000oOO ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( iII ) . split ( ) , o0 , Oo0oOOo , Oo0OoO00oOO0o )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'episodes' )
   else :
    O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
    O00oO = base64 . b64decode ( O00oO )
    oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
    tools . addDir ( O00oO , url , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 71 - 71: oo * II111iiii * OoOooOOOO
 if 56 - 56: OOooo000oo0
def O0oO ( url ) :
 log ( url )
 if url == "vod" :
  open = tools . OPEN_URL ( OooO0 )
 else :
  open = tools . OPEN_URL ( url )
 log ( open )
 oo0OooOOo0 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for o0O in oo0OooOOo0 :
  if '<playlist_url>' in open :
   O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
   I11i1I1I = tools . regex_from_to ( o0O , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( O00oO ) ) . replace ( '?' , '' ) , I11i1I1I , 20 , o0OoOoOO00 , I11i , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
     O00oO = base64 . b64decode ( O00oO )
     oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
     O0OOO0OOoO0O = base64 . b64decode ( O0OOO0OOoO0O )
     OOoO0O00o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'PLOT:' , '\n' )
     iII = tools . regex_from_to ( O0OOO0OOoO0O , 'CAST:' , '\n' )
     o0 = tools . regex_from_to ( O0OOO0OOoO0O , 'RATING:' , '\n' )
     ooOooo000oOO = tools . regex_from_to ( O0OOO0OOoO0O , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     ooOooo000oOO = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( ooOooo000oOO )
     Oo0oOOo = tools . regex_from_to ( O0OOO0OOoO0O , 'DURATION_SECS:' , '\n' )
     Oo0OoO00oOO0o = tools . regex_from_to ( O0OOO0OOoO0O , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( O00oO ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , oo000OO00Oo , I11i , OOoO0O00o0 , str ( ooOooo000oOO ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( iII ) . split ( ) , o0 , Oo0oOOo , Oo0OoO00oOO0o )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
   else :
    O00oO = tools . regex_from_to ( o0O , '<title>' , '</title>' )
    O00oO = base64 . b64decode ( O00oO )
    oo000OO00Oo = tools . regex_from_to ( o0O , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( o0O , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O0OOO0OOoO0O = tools . regex_from_to ( o0O , '<description>' , '</description>' )
    tools . addDir ( O00oO , url , 4 , oo000OO00Oo , I11i , base64 . b64decode ( O0OOO0OOoO0O ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 73 - 73: iI1 * i11iIiiIii % OoOooOOOO . iI1
 if 66 - 66: OoOooOOOO + OoOooOOOO + IiIiIi / ooO0O + I1
 if 30 - 30: O0
def iIi1 ( url ) :
 url = str ( url ) . replace ( 'USERNAME' , i11iiII ) . replace ( 'PASSWORD' , I1iiiiI1iII )
 OoOOoOooooOOo = xbmcgui . ListItem ( '' , iconImage = 'DefaultVideo.png' , thumbnailImage = o0OoOoOO00 )
 OoOOoOooooOOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : '' , 'Plot' : '' } )
 OoOOoOooooOOo . setProperty ( 'IsPlayable' , 'true' )
 OoOOoOooooOOo . setPath ( str ( url ) )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OoOOoOooooOOo )
 if 87 - 87: OOooo000oo0
 if 58 - 58: IIIiiIIii % o00oo
def i1OOoO ( ) :
 tools . addDir ( '[COLOR white]All Movies[/COLOR]' , 'vod' , 333 , O0oo0OO0 , I11i , '' )
 tools . addDir ( '[COLOR white]Movie Categories[/COLOR]' , 'vod' , 3 , O0oo0OO0 , I11i , '' )
 tools . addDir ( '[COLOR white]Search Movies[/COLOR]' , 'url' , 5 , oo00 , I11i , '' )
 if 89 - 89: o00oo + ii1IiI1i * i1Ii * o00O00O0O0O
def iiIiI1i1 ( ) :
 tools . addDir ( '[COLOR white]TV Show Categories[/COLOR]' , II11iiii1Ii , 24 , I1i1iiI1 , I11i , '' )
 tools . addDir ( '[COLOR white]Search TV Shows[/COLOR]' , O0o0Oo , 2424 , oo00 , I11i , '' )
 if 69 - 69: IiIiIi
def OOo0oO00ooO00 ( ) :
 I11iII = control . inputDialog ( heading = 'Search Neptune:' )
 if I11iII == "" :
  return
 else :
  return I11iII
  if 5 - 5: OOooo000oo0
  if 48 - 48: o00oo - OoOooOOOO / OoooooooOO
def I11iII ( ) :
 if OO0O0 == ( [ 3 , 4 , 20 , 21 ] ) :
  return False
  if 30 - 30: I1 + iI1 * i1Ii % i11iIiiIii % IIIiiIIii
 I1i1Iiiii = xbmcgui . Dialog ( ) . input ( "Search for a Movie ?" )
 xbmc . log ( repr ( I1i1Iiiii ) , xbmc . LOGERROR )
 if not I1i1Iiiii :
  xbmc . executebuiltin ( "XBMC.Notification([COLOR red][B]Search is Empty[/B][/COLOR],Aborting search,4000," + o0OoOoOO00 + ")" )
  return
 xbmc . log ( str ( I1i1Iiiii ) )
 open = tools . OPEN_URL ( OO0o )
 import json
 OO0OoOO0o0o = json . loads ( open )
 ooI1111i = OO0OoOO0o0o [ "available_channels" ]
 for id , iIIii in ooI1111i . items ( ) :
  O00oO = iIIii [ "name" ] or ''
  type = iIIii [ "stream_type" ] or ''
  o00O0O = iIIii [ "container_extension" ] or ''
  oo000OO00Oo = iIIii [ "stream_icon" ] or ''
  I11i = ''
  OoOOoOooooOOo = xbmcgui . ListItem ( O00oO , iconImage = oo000OO00Oo , thumbnailImage = oo000OO00Oo )
  OoOOoOooooOOo . setInfo ( type = "Video" , infoLabels = { "Title" : O00oO , "Plot" : '' , } )
  OoOOoOooooOOo . setProperty ( 'fanart_image' , I11i )
  OoOOoOooooOOo . setProperty ( "IsPlayable" , "true" )
  Ooo = '%s:%s/%s/%s/%s/' % ( iii11iII , i1I111I , type , i11iiII , I1iiiiI1iII )
  xbmc . log ( repr ( O00oO ) )
  if I1i1Iiiii in O00oO . lower ( ) :
   if 20 - 20: i1IIi - IiIiIi
   Ooo = '%s:%s/%s/%s/%s/' % ( iii11iII , i1I111I , type , i11iiII , I1iiiiI1iII )
   i1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ooo + id + '.' + o00O0O , listitem = OoOOoOooooOOo , isFolder = False )
  elif I1i1Iiiii not in O00oO . lower ( ) and I1i1Iiiii in O00oO :
   if 94 - 94: iIii1I11I1II1 / i1 % ooO0O * ooO0O * II111iiii
   Ooo = '%s:%s/%s/%s/%s/' % ( iii11iII , i1I111I , type , i11iiII , I1iiiiI1iII )
   i1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ooo + id + '.' + o00O0O , listitem = OoOOoOooooOOo , isFolder = False )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 29 - 29: ii1IiI1i + IIIiiIIii / o00oo / I1 * iIii1I11I1II1
def iiii11I ( url , description ) :
 if url == "CC" :
  tools . clear_cache ( )
 elif url == "AS" :
  xbmc . executebuiltin ( 'Addon.OpenSettings(%s)' % IiII1IiiIiI1 )
 elif url == "ADS" :
  iIiIIi1 = xbmcgui . Dialog ( ) . select ( 'Edit Advanced Settings' , [ 'Enable Fire TV Stick AS' , 'Enable Fire TV AS' , 'Enable 1GB Ram or Lower AS' , 'Enable 2GB Ram or Higher AS' , 'Enable Nvidia Shield AS' , 'Disable AS' ] )
  if iIiIIi1 == 0 :
   O0OO ( 'stick' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 1 :
   O0OO ( 'firetv' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 2 :
   O0OO ( 'lessthan' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 3 :
   O0OO ( 'morethan' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 4 :
   O0OO ( 'shield' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 5 :
   O0OO ( 'remove' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Advanced Settings Removed' )
 elif url == "ADS2" :
  iIiIIi1 = xbmcgui . Dialog ( ) . select ( 'Select Your Device Or Closest To' , [ 'Fire TV Stick ' , 'Fire TV' , '1GB Ram or Lower' , '2GB Ram or Higher' , 'Nvidia Shield' ] )
  if iIiIIi1 == 0 :
   O0OO ( 'stick' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 1 :
   O0OO ( 'firetv' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 2 :
   O0OO ( 'lessthan' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 3 :
   O0OO ( 'morethan' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
  elif iIiIIi1 == 4 :
   O0OO ( 'shield' )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'Set Advanced Settings' )
 elif url == "tv" :
  iIiIIi1 = xbmcgui . Dialog ( ) . select ( 'Select a TV Guide to Setup' , [ 'iVue TV Guide' , 'PVR TV Guide' , 'Both' ] )
  if iIiIIi1 == 0 :
   ivueint ( )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'iVue Integration Complete' )
  elif iIiIIi1 == 1 :
   pvrsetup ( )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'PVR Integration Complete' )
  elif iIiIIi1 == 2 :
   pvrsetup ( )
   ivueint ( )
   xbmcgui . Dialog ( ) . ok ( 'Neptune' , 'PVR & iVue Integration Complete' )
 elif url == "ST" :
  xbmc . executebuiltin ( 'Runscript("special://home/addons/plugin.video.neptuneiptv/resources/modules/speedtest.py")' )
 elif url == "META" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'meta' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'meta' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "XXX" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'hidexxx' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'hidexxx' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "LO" :
  xbmcaddon . Addon ( ) . setSetting ( 'Username' , '' )
  xbmcaddon . Addon ( ) . setSetting ( 'Password' , '' )
  xbmc . executebuiltin ( 'XBMC.ActivateWindow(Videos,addons://sources/video/)' )
  xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "UPDATE" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'update' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'update' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   if 6 - 6: iIii1I11I1II1 % i11iIiiIii % iI1
def o0Oo0oO0oOO00 ( ) :
 open = tools . OPEN_URL ( OO0o )
 import json
 OO0OoOO0o0o = json . loads ( open )
 ooI1111i = OO0OoOO0o0o [ "available_channels" ]
 for id , iIIii in ooI1111i . items ( ) :
  O00oO = iIIii [ "name" ] or ''
  type = iIIii [ "stream_type" ] or ''
  o00O0O = iIIii [ "container_extension" ] or ''
  oo000OO00Oo = iIIii [ "stream_icon" ] or ''
  I11i = ''
  OoOOoOooooOOo = xbmcgui . ListItem ( O00oO , iconImage = oo000OO00Oo , thumbnailImage = oo000OO00Oo )
  OoOOoOooooOOo . setInfo ( type = "Video" , infoLabels = { "Title" : O00oO , "Plot" : '' , } )
  OoOOoOooooOOo . setProperty ( 'fanart_image' , I11i )
  OoOOoOooooOOo . setProperty ( "IsPlayable" , "true" )
  Ooo = '%s:%s/%s/%s/%s/' % ( iii11iII , i1I111I , type , i11iiII , I1iiiiI1iII )
  i1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ooo + id + '.' + o00O0O , listitem = OoOOoOooooOOo , isFolder = False )
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_VIDEO_TITLE )
 if 92 - 92: OoooooooOO * O0OOooO
def O0OO ( device ) :
 if device == 'stick' :
  file = open ( os . path . join ( III1ii1iII , 'stick.xml' ) )
 elif device == 'firetv' :
  file = open ( os . path . join ( III1ii1iII , 'firetv.xml' ) )
 elif device == 'lessthan' :
  file = open ( os . path . join ( III1ii1iII , 'lessthan1GB.xml' ) )
 elif device == 'morethan' :
  file = open ( os . path . join ( III1ii1iII , 'morethan1GB.xml' ) )
 elif device == 'shield' :
  file = open ( os . path . join ( III1ii1iII , 'shield.xml' ) )
 elif device == 'remove' :
  os . remove ( oo0oooooO0 )
  if 100 - 100: O0OOooO + O0OOooO * oo
 try :
  I1i = file . read ( )
  O00Oooo = open ( oo0oooooO0 , mode = 'w+' )
  O00Oooo . write ( I1i )
  O00Oooo . close ( )
 except :
  pass
  if 46 - 46: i1Ii / o00O00O0O0O
  if 57 - 57: oo / ooO0O * O0 - OoooooooOO % iIii1I11I1II1
def ii11i ( ) :
 o0oooOO00 = xbmcgui . Dialog ( ) . yesno ( 'Neptune' , 'Please Select The RAM Size of Your Device' , yeslabel = 'Less than 1GB RAM' , nolabel = 'More than 1GB RAM' )
 if o0oooOO00 :
  iiIiii1IIIII ( )
 else :
  o00o ( )
  if 45 - 45: iI1 . o00oo . iI1 - OOooo000oo0 . o00oo
  if 12 - 12: O0 - o00oo
def o00o ( ) :
 file = open ( os . path . join ( III1ii1iII , 'morethan.xml' ) )
 o0O = file . read ( )
 O00Oooo = open ( oo0oooooO0 , mode = 'w+' )
 O00Oooo . write ( o0O )
 O00Oooo . close ( )
 if 81 - 81: IIIiiIIii - IIIiiIIii . ooO0O
 if 73 - 73: i1Ii % i11iIiiIii - OOooo000oo0
def iiIiii1IIIII ( ) :
 file = open ( os . path . join ( III1ii1iII , 'lessthan.xml' ) )
 o0O = file . read ( )
 O00Oooo = open ( oo0oooooO0 , mode = 'w+' )
 O00Oooo . write ( o0O )
 O00Oooo . close ( )
 if 7 - 7: O0 * i11iIiiIii * o00O00O0O0O + IiIiIi % ii1IiI1i - IiIiIi
 if 39 - 39: i1 * I1 % I1 - OoooooooOO + o00oo - i1Ii
def I1I ( ) :
 iiO0oOo00o = xbmc . Keyboard ( '' , 'heading' , True )
 iiO0oOo00o . setHeading ( 'Enter Username' )
 iiO0oOo00o . setHiddenInput ( False )
 iiO0oOo00o . doModal ( )
 if ( iiO0oOo00o . isConfirmed ( ) ) :
  I1i1Iiiii = iiO0oOo00o . getText ( )
  return I1i1Iiiii
 else :
  return False
  if 81 - 81: oo % i1IIi . iIii1I11I1II1
  if 4 - 4: i11iIiiIii % ii1IiI1i % i1IIi / oo
def OoOo ( ) :
 iiO0oOo00o = xbmc . Keyboard ( '' , 'heading' , True )
 iiO0oOo00o . setHeading ( 'Enter Password' )
 iiO0oOo00o . setHiddenInput ( False )
 iiO0oOo00o . doModal ( )
 if ( iiO0oOo00o . isConfirmed ( ) ) :
  I1i1Iiiii = iiO0oOo00o . getText ( )
  return I1i1Iiiii
 else :
  return False
  if 6 - 6: ooO0O / OOooo000oo0 % I1 - OOooo000oo0
  if 31 - 31: I1
def i1OOO0000oO ( ) :
 open = tools . OPEN_URL ( OO0o )
 try :
  i11iiII = tools . regex_from_to ( open , '"username":"' , '"' )
  I1iiiiI1iII = tools . regex_from_to ( open , '"password":"' , '"' )
  iI1i111I1Ii = tools . regex_from_to ( open , '"status":"' , '"' )
  i11i1ii1I = tools . regex_from_to ( open , '"max_connections":"' , '"' )
  o0OO0o0o00o = tools . regex_from_to ( open , '"active_cons":"' , '"' )
  oOo0 = tools . regex_from_to ( open , '"exp_date":"' , '"' )
  oOo0 = datetime . datetime . fromtimestamp ( int ( oOo0 ) ) . strftime ( '%d/%m/%Y - %H:%M' )
  OOOoOO = re . compile ( '^(.*?)/(.*?)/(.*?)$' , re . DOTALL ) . findall ( oOo0 )
  for I11IIIi , iIIiiI1II1i11 , ooOooo000oOO in OOOoOO :
   iIIiiI1II1i11 = tools . MonthNumToName ( iIIiiI1II1i11 )
   ooOooo000oOO = re . sub ( ' -.*?$' , '' , ooOooo000oOO )
   oOo0 = iIIiiI1II1i11 + ' ' + I11IIIi + ' - ' + ooOooo000oOO
   tools . addDir ( '[B][COLOR red]Account Status :[/COLOR][/B] %s' % iI1i111I1Ii , '' , '' , oo0o0O00 , I11i , '' )
   tools . addDir ( '[B][COLOR red]Expiry Date:[/COLOR][/B] ' + oOo0 , '' , '' , oO0o0o0ooO0oO , I11i , '' )
   tools . addDir ( '[B][COLOR red]Username :[/COLOR][/B] ' + i11iiII , '' , '' , o0oOoO00o , I11i , '' )
   tools . addDir ( '[B][COLOR red]Password :[/COLOR][/B] ' + I1iiiiI1iII , '' , '' , i1oOOoo00O0O , I11i , '' )
   tools . addDir ( '[B][COLOR red]Allowed Connections:[/COLOR][/B] ' + i11i1ii1I , '' , '' , Oo0oO0ooo , I11i , '' )
   tools . addDir ( '[B][COLOR red]Current Connections:[/COLOR][/B] ' + o0OO0o0o00o , '' , '' , o00 , I11i , '' )
 except : pass
 if 65 - 65: o00O00O0O0O / i1Ii / IIIiiIIii
 if 92 - 92: O0 - ooO0O . I1 * o00O00O0O0O
def I1iI ( ) :
 if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
  IIIIiIiIi1 = '[B][COLOR lime]ON[/COLOR][/B]'
 else :
  IIIIiIiIi1 = '[B][COLOR red]OFF[/COLOR][/B]'
 if xbmcaddon . Addon ( ) . getSetting ( 'hidexxx' ) == 'true' :
  I11iiiiI1i = '[B][COLOR lime]ON[/COLOR][/B]'
 else :
  I11iiiiI1i = '[B][COLOR red]OFF[/COLOR][/B]'
 tools . addDir ( 'Metadata is %s' % IIIIiIiIi1 , 'META' , 10 , Oo0o0000o0o0 , I11i , IIIIiIiIi1 )
 tools . addDir ( 'XXX Channels are %s' % I11iiiiI1i , 'XXX' , 10 , oOo0oooo00o , I11i , I11iiiiI1i )
 tools . addDir ( 'Clear Cache' , 'CC' , 10 , i1111 , I11i , '' )
 tools . addDir ( 'Edit Advanced Settings' , 'ADS' , 10 , i11 , I11i , '' )
 tools . addDir ( 'Run a Speed Test' , 'ST' , 10 , I11 , I11i , '' )
 if 40 - 40: iI1 + i1IIi * I1
O0oOOoooOO0O = tools . get_params ( )
ooo00Ooo = None
O00oO = None
OO0O0 = None
Oo0o0O00 = None
ii1 = None
I1i11 = None
type = None
if 51 - 51: ii1IiI1i . OOooo000oo0 * IiIiIi % o00O00O0O0O + II111iiii . IiIiIi
try :
 ooo00Ooo = urllib . unquote_plus ( O0oOOoooOO0O [ "url" ] )
except :
 pass
try :
 O00oO = urllib . unquote_plus ( O0oOOoooOO0O [ "name" ] )
except :
 pass
try :
 Oo0o0O00 = urllib . unquote_plus ( O0oOOoooOO0O [ "iconimage" ] )
except :
 pass
try :
 OO0O0 = int ( O0oOOoooOO0O [ "mode" ] )
except :
 pass
try :
 ii1 = urllib . unquote_plus ( O0oOOoooOO0O [ "description" ] )
except :
 pass
try :
 I1i11 = urllib . unquote_plus ( O0oOOoooOO0O [ "query" ] )
except :
 pass
try :
 type = urllib . unquote_plus ( O0oOOoooOO0O [ "type" ] )
except :
 pass
 if 50 - 50: ii1IiI1i * I1 % O0
if OO0O0 == None or ooo00Ooo == None or len ( ooo00Ooo ) < 1 :
 I1i1I1II ( )
 if 62 - 62: O0 % i1Ii . i1Ii - iIii1I11I1II1 / i11iIiiIii
elif OO0O0 == 1 :
 II1III ( ooo00Ooo )
 if 31 - 31: iIii1I11I1II1 / ii1IiI1i / iI1
elif OO0O0 == 2 :
 iIIIIii1 ( ooo00Ooo )
 if 41 - 41: i1
elif OO0O0 == 3 :
 oO ( ooo00Ooo )
 if 10 - 10: i1 / i1 / O0OOooO . O0OOooO
elif OO0O0 == 333 :
 o0Oo0oO0oOO00 ( )
 if 98 - 98: i1 / OOooo000oo0 . O0 + ii1IiI1i
elif OO0O0 == 4 :
 iIi1 ( ooo00Ooo )
 if 43 - 43: II111iiii . OoOooOOOO / iI1
elif OO0O0 == 5 :
 I11iII ( )
 if 20 - 20: OOooo000oo0
elif OO0O0 == 6 :
 i1OOO0000oO ( )
 if 95 - 95: ooO0O - OOooo000oo0
elif OO0O0 == 9 :
 xbmc . executebuiltin ( 'ActivateWindow(busydialog)' )
 tools . Trailer ( ) . play ( ooo00Ooo )
 xbmc . executebuiltin ( 'Dialog.Close(busydialog)' )
 if 34 - 34: IiIiIi * OOooo000oo0 . i1IIi * IiIiIi / IiIiIi
elif OO0O0 == 10 :
 iiii11I ( ooo00Ooo , ii1 )
 if 30 - 30: iI1 + i1 / i1 % iI1 . iI1
elif OO0O0 == 11 :
 i1OOoO ( )
 if 55 - 55: IiIiIi - i1Ii + II111iiii + ooO0O % o00O00O0O0O
elif OO0O0 == 12 :
 iiIiI1i1 ( )
 if 41 - 41: i1IIi - i1Ii - o00O00O0O0O
elif OO0O0 == 13 :
 O0o0O00Oo0o0 ( )
 if 8 - 8: ii1IiI1i + O0OOooO - o00oo % i1 % o00oo * OoOooOOOO
elif OO0O0 == 14 :
 o000O0o ( O00oO , ii1 )
 if 9 - 9: i1 - i11iIiiIii - I1 * o00O00O0O0O + IiIiIi
elif OO0O0 == 15 :
 listcatchup2 ( )
 if 44 - 44: II111iiii
elif OO0O0 == 16 :
 I1iI ( )
 if 52 - 52: iI1 - i1 + iI1 % o00oo
elif OO0O0 == 17 :
 shortlinks . Get ( )
 if 35 - 35: iIii1I11I1II1
elif OO0O0 == 19 :
 get ( )
 if 42 - 42: O0OOooO . OOooo000oo0 . i1IIi + IIIiiIIii + I1 + OOooo000oo0
elif OO0O0 == 20 :
 O0oO ( ooo00Ooo )
 if 31 - 31: ooO0O . I1 - IiIiIi . OoooooooOO / OoooooooOO
elif OO0O0 == 21 :
 Ii1I1Ii ( ooo00Ooo )
 if 56 - 56: ii1IiI1i / OoOooOOOO / i11iIiiIii + OoooooooOO - i1 - i1Ii
elif OO0O0 == 22 :
 O00o0OO0 ( ooo00Ooo )
 if 21 - 21: O0 % oo . OOooo000oo0 / II111iiii + oo
elif OO0O0 == 24 :
 oOO0O00oO0Ooo ( ooo00Ooo )
 if 53 - 53: OoOooOOOO - OOooo000oo0 - OoOooOOOO * ooO0O
elif OO0O0 == 2424 :
 I11iiI1i1 ( ooo00Ooo )
 if 71 - 71: O0 - iIii1I11I1II1
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )