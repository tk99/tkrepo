# -*- coding: utf-8 -*-
#------------------------------------------------------------
# The X Factor International
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.tubeheroes'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

ART = xbmc.translatePath(os.path.join(
	'special://home/addons/' + addonID + '/resources/art/'))
    
dan = ART + 'dan.jpg'
capt = ART + 'capt.jpg'
ali = ART + 'ali.jpg'
lds = ART + 'lds.jpg'
cave = ART + 'caveman.jpg'
sky = ART + 'sky.jpg'
popular = ART + 'popular.jpg'
gaming = ART + 'gamingwith.jpg'
ssundee = ART + 'ssundee.jpg'
lachlan = ART + 'lachlan.jpg'
little = ART + 'littlelizard.jpg'
atlantic = ART + 'theatlantic.jpg'
exploding = ART + 'exploding.jpg'
vikkstar = ART + 'vikkstar.jpg'
jerome = ART + 'jerome.jpg'
ashley = ART + 'ashley.jpg'
deadlox = ART + 'deadlox.jpg'
choo = ART + 'choochoos.jpg'
ant = ART + 'antvenom.jpg'

YOUTUBE_CHANNEL_ID1 = "TheDiamondMinecart"
YOUTUBE_CHANNEL_ID2 = "CaptainSparklez"
YOUTUBE_CHANNEL_ID3 = "Matroix"
YOUTUBE_CHANNEL_ID4 = "ldshadowlady"
YOUTUBE_CHANNEL_ID5 = "CavemanFilms"
YOUTUBE_CHANNEL_ID6 = "SkyDoesMinecraft"
YOUTUBE_CHANNEL_ID7 = "PopularMMOs"
YOUTUBE_CHANNEL_ID8 = "GamingWithJen"
YOUTUBE_CHANNEL_ID9 = "SSundee"
YOUTUBE_CHANNEL_ID10 = "CraftBattleDuty"
YOUTUBE_CHANNEL_ID11 = "LittleLizardGaming"
YOUTUBE_CHANNEL_ID12 = "TheAtlanticCraft"
YOUTUBE_CHANNEL_ID13 = "ExplodingTNT"
YOUTUBE_CHANNEL_ID14 = "Vikkstar123"
YOUTUBE_CHANNEL_ID15 = "JeromeASF"
YOUTUBE_CHANNEL_ID16 = "AshleyMarieeGaming"
YOUTUBE_CHANNEL_ID17 = "DeadloxMC"
YOUTUBE_CHANNEL_ID18 = "ChooChoosGaming"
YOUTUBE_CHANNEL_ID19 = "AntVenom"
YOUTUBE_CHANNEL_ID20 = "MoreAliA"

# Entry point
def run():
    plugintools.log("tubeheroes.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("XFactorInternational.main_list "+repr(params))
        
    plugintools.add_item( 
        #action="", 
        title="DanTDM",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail=dan,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="CaptainSparklez",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail=capt,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Ali-A",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail=ali,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="More Ali-A",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID20+"/",
        thumbnail=ali,
        folder=True )        
        
    plugintools.add_item( 
        #action="", 
        title="LDShadowLady",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail=lds,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="CavemanFilms",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail=cave,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Sky",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID6+"/",
        thumbnail=sky,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="PopularMMOs",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail=popular,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="GamingWithJen",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail=gaming,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="SSundee",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID9+"/",
        thumbnail=ssundee,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Lachlan",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID10+"/",
        thumbnail=lachlan,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="LittleLizardGaming",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID11+"/",
        thumbnail=little,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="TheAtlanticCraft",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID12+"/",
        thumbnail=atlantic,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="ExplodingTNT",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID13+"/",
        thumbnail=exploding,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Vikkstar123",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID14+"/",
        thumbnail=vikkstar,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="JeromeASF",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID15+"/",
        thumbnail=jerome,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="AshleyMarieeGaming",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID16+"/",
        thumbnail=ashley,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Deadlox",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID17+"/",
        thumbnail=deadlox,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="ChooChoosGaming",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID18+"/",
        thumbnail=choo,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="AntVenom",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID19+"/",
        thumbnail=ant,
        folder=True )

run()