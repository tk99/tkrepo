import xbmc,xbmcaddon,xbmcgui,base64,xbmcplugin,os,shutil,urllib2,urllib,re,time,socket,net,plugintools
net             = net.Net()

addon_id        = 'plugin.video.tkmain'
ADDON           = xbmcaddon.Addon(id=addon_id)
selfAddon       = xbmcaddon.Addon(id=addon_id)
datapath        = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
dialog          = xbmcgui.Dialog()
addonspath      = xbmc.translatePath(os.path.join('special://home/addons/', ''))
udpath          = xbmc.translatePath(os.path.join('special://home/userdata/', ''))
AddonTitle 		= "TK Maintenance"
AddonID	        = 'plugin.video.tkmain'
zip          =  ADDON.getSetting('zip')
dialog       =  xbmcgui.Dialog()
dp           =  xbmcgui.DialogProgress()
USERDATA     =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA   =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS       =  xbmc.translatePath(os.path.join('special://home','addons'))
FAVS         =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
USB          =  xbmc.translatePath(os.path.join(zip))


EXCLUDES = ['plugin.video.wizard2', 'repository.tk99', 'plugin.video.tkmain', 'plugin.program.tknotify']

DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails')

ART = xbmc.translatePath(os.path.join(
	'special://home/addons/' + AddonID + '/resources/art/'))
    
FANART = ART + 'fanart.png'
ICON = ART + 'icon.png'

# set some default icons
mainticon = ART + 'maint.png'
cacheicon = ART + 'cache.png'
userdataicon = ART + 'freshstart.png'
packagesicon = ART + 'packages.png'
speedicon = ART + 'speed.png' 
favicon = ART + 'fav.png'

if zip=='' and ADDON.getSetting('email')=='':
    if dialog.yesno("USB BACKUP/RESTORE", "You Have Not Set Your Storage Path", 'Set The Storage Path Now ?',''):
        ADDON.openSettings()
        
def RESTORE_BACKUP_XML(name,url,description):
    if 'Backup' in name:
        TO_READ   = open(url).read()
        TO_WRITE  = os.path.join(USB,description.split('Your ')[1])
        
        f = open(TO_WRITE, mode='w')
        f.write(TO_READ)
        f.close() 
         
    else:
    
        if 'guisettings.xml' in description:
            a = open(os.path.join(USB,description.split('Your ')[1])).read()
            
            r='<setting type="(.+?)" name="%s.(.+?)">(.+?)</setting>'% skin
            
            match=re.compile(r).findall(a)
            
            for type,string,setting in match:
                setting=setting.replace('&quot;','') .replace('&amp;','&') 
                xbmc.executebuiltin("Skin.Set%s(%s,%s)"%(type.title(),string,setting))  
        else:    
            TO_WRITE   = os.path.join(url)
            TO_READ  = open(os.path.join(USB,description.split('Your ')[1])).read()
            
            f = open(TO_WRITE, mode='w')
            f.write(TO_READ)
            f.close()  
    dialog.ok("USB BACKUP/RESTORE", "", 'All Done !','')     
    
def CATEGORIES():
        addDir('Factory Reset Kodi', 'url', 5, userdataicon, 'Reset your Kodi to its default settings, this will remove all addons, settings and skins')
        addDir('Delete Cache', 'url', 9, cacheicon, 'Delete cache files')
        addDir('Delete Package files', 'url', 10, packagesicon, 'Delete the Package Files')
        addDir('Speed Test', 'url', 12, speedicon, 'Speed Test')
        addFol('Backup/Restore Favourites', 'url', 6, favicon, 'Backup/Restore Favourites')
        setView('movies', 'MAIN')

def FRESHSTART(params): # Main menu
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to clear the Kodi userdata whilst leaving Update Wizard 4.0 installed?","[COLOR red]DO NOT PRESS ANY BUTTONS AFTER SELECTING YES UNTIL PROMPTED![/COLOR]")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
		dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"Process is complete, you've got a clean install!","Select yes to force close on the next screen in order for the changes to be applied. Update wizard can then be found by selecting the programs menu bar in Kodi")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"Process is complete, you've got a clean install!","Select yes to force close on the next screen in order for the changes to be applied. Update wizard can then be found by selecting the programs menu bar in Kodi")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
	killxbmc()		
    
def maint():
	addDir('Backup Favourites',FAVS,4,'','Back Up Your favourites.xml')
	addDir('Restore Favourites',FAVS,4,'','Restore Your favourites.xml')
	setView('movies', 'MAIN')	

def packages(url):
	print '###'+AddonTitle+' - DELETING PACKAGES###'
	packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
	try:	
		for root, dirs, files in os.walk(packages_cache_path):
			file_count = 0
			file_count += len(files)
			
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Package Files", str(file_count) + " files found", "Do you want to delete them?"):
							
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
					dialog = xbmcgui.Dialog()
					dialog.ok(AddonTitle, "Deleting Packages all done")
				else:
						pass
			else:
				dialog = xbmcgui.Dialog()
				dialog.ok(AddonTitle, "No Packages to Delete")
	except: 
		dialog = xbmcgui.Dialog()
		dialog.ok(AddonTitle, "Error Deleting Packages")
	return	
	
def cache(url):
	print '############################################################	   DELETING STANDARD CACHE			 ###############################################################'
	xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
	if os.path.exists(xbmc_cache_path)==True:	
		for root, dirs, files in os.walk(xbmc_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete KODI Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						try:
							os.unlink(os.path.join(root, f))
						except:
							pass
					for d in dirs:
						try:
							shutil.rmtree(os.path.join(root, d))
						except:
							pass
						
			else:
				pass
	if xbmc.getCondVisibility('system.platform.ATV2'):
		atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
		
		for root, dirs, files in os.walk(atv2_cache_a):
			file_count = 0
			file_count += len(files)
		
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass
		atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
		
		for root, dirs, files in os.walk(atv2_cache_b):
			file_count = 0
			file_count += len(files)
		
			if file_count > 0:

				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass
			  # Set path to Cydia Archives cache files
							 

	# Set path to What th Furk cache files
	wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
	if os.path.exists(wtf_cache_path)==True:	
		for root, dirs, files in os.walk(wtf_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass
				
				# Set path to 4oD cache files
	channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
	if os.path.exists(channel4_cache_path)==True:	
		for root, dirs, files in os.walk(channel4_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass
				
				# Set path to BBC iPlayer cache files
	iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
	if os.path.exists(iplayer_cache_path)==True:	
		for root, dirs, files in os.walk(iplayer_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass
				
				
				# Set path to Simple Downloader cache files
	downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
	if os.path.exists(downloader_cache_path)==True:	
		for root, dirs, files in os.walk(downloader_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass
				
				# Set path to ITV cache files
	itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(itv_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass

				# Set path to movies4me cache files
	m4me_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.movies4me/cache'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(m4me_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Movies4me Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass

					# Set path to phoenix cache files
	phoenix_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.phstreams/Cache'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(phoenix_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Phoenix Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass

					# Set path to youtube music cache files
	ytmusic_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.spotitube/cache'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(ytmusic_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete YouTube Music Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass

					# Set path to supercartoons cache files
	supercartoons_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.supercartoons/cache'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(supercartoons_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete SuperCartoons Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass

					# Set path to tvonline.cc cache files
	tvonline_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.tvonline.cc/cache'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(tvonline_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete TVonline Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass

					# Set path to youtube cache files
	youtube_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.youtube/kodion'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(youtube_cache_path):
			file_count = 0
			file_count += len(files)
		
		# Count files and give option to delete
			if file_count > 0:
	
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete YouTube Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
				
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))
						
			else:
				pass

			   # Set path to temp cache files
	temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
	if os.path.exists(temp_cache_path)==True:	
		for root, dirs, files in os.walk(temp_cache_path):
			file_count = 0
			file_count += len(files)
	   
		# Count files and give option to delete
			if file_count > 0:
   
				dialog = xbmcgui.Dialog()
				if dialog.yesno("Delete Temp Files", str(file_count) + " files found", "Do you want to delete them?"):
			   
					for f in files:
						os.unlink(os.path.join(root, f))
					for d in dirs:
						shutil.rmtree(os.path.join(root, d))

					# Set path to exodus cache files
	
	exodus_cache_path = xbmc.translatePath('special://masterprofile/addon_data/plugin.video.exodus')
	dialog = xbmcgui.Dialog()
	try:
		if dialog.yesno("Delete Exodus Cache Files", "Do you want to delete cache"):
			genesiscache = os.path.join(exodus_cache_path,"cache.db")
			os.unlink(genesiscache)

	except:
		pass
	
	dialog = xbmcgui.Dialog()
	dialog.ok("TK Maintenance", "Finished Deleting Cache Files")	
    
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 
    
def addDir(name,url,mode,iconimage,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
        if mode==5 or mode==1:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok		
	
def addFol(name,url,mode,iconimage,fanart,description=''):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok	
    
def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
   
 
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
 
def killxbmc():
	choice = plugintools.message_yes_no('Force Close Kodi', 'You are about to close Kodi','Would you like to continue?')
	if choice == 0:
		return
	elif choice == 1:
		pass
	myplatform = platform()
	print "Platform: " + str(myplatform)

	try:
		os._exit(1)
	except:
		pass

	if myplatform == 'osx':  # OSX
		print "############   try osx force close  #################"
		try:
			os.system('killall -9 XBMC')
		except:
			pass
		try:
			os.system('killall -9 Kodi')
		except:
			pass
		plugintools.message(AddonTitle, "Force Close has failed, to complete the update","Press 'OK' then disconnect the power cable as normal [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'linux':  # Linux
		print "############   try linux force close  #################"
		try:
			os.system('killall XBMC')
		except:
			pass
		try:
			os.system('killall Kodi')
		except:
			pass
		try:
			os.system('killall -9 xbmc.bin')
		except:
			pass
		try:
			os.system('killall -9 kodi.bin')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close","was unsuccessful. Please force close Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.", '')
	elif myplatform == 'android':  # Android

		print "############   try android force close  #################"

		try:
			os._exit(1)
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc.kodi')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.kodi')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc.xbmc')
		except:
			pass
		try:
			os.system('adb shell am force-stop org.xbmc')
		except:
			pass
		try:
			os.system('adb shell am force-stop com.semperpax.spmc16')
		except:
			pass
		try:
			os.system('adb shell am force-stop com.spmc16')
		except:
			pass
		time.sleep(5)
		plugintools.message(AddonTitle,"[COLOR=yellow][B] Force Close has failed, to complete the update[/COLOR][/B]" , "Press 'OK' then disconnect the power cable as normal" )
	elif myplatform == 'windows':  # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except:
			pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except:
			pass
		plugintools.message(AddonTitle, "[COLOR=red][B]WARNING  !!![/COLOR][/B]" , "If you\'re seeing this message it means the force close" , "was unsuccessful. Please force close Kodi [COLOR=lime]DO NOT[/COLOR] exit this menu." , "press CTRL-ALT-DEL, start task manager and end the Kodi process")
	else:  # ATV
		print "############   try atv force close  #################"
		try:
			os.system('killall AppleTV')
		except:
			pass
		print "############   try raspbmc force close  #################"  # OSMC / Raspbmc
		try:
			os.system('sudo initctl stop kodi')
		except:
			pass
		try:
			os.system('sudo initctl stop xbmc')
		except:
			pass
		plugintools.message(AddonTitle, "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")


def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'
  
params=get_params();url=None;name=None;mode=None;iconimage=None;description=None
try:url=urllib.unquote_plus(params["url"])
except:pass
try:name=urllib.unquote_plus(params["name"])
except:pass
try:iconimage=urllib.unquote_plus(params["iconimage"])
except:pass
try:mode=int(params["mode"])
except:pass
try:description=urllib.unquote_plus(params["description"])
except:pass

if mode==None or url==None or len(url)<1:CATEGORIES()
elif mode==5:FRESHSTART(params)
elif mode==6:maint()
elif mode==9:cache(url)
elif mode==10:packages(url)
elif mode==12:import speedtest
elif mode==1:BACKUP_OPTION()
        
elif mode==4:
        xbmc.log("############   RESTORE_BACKUP_XML #################")
        RESTORE_BACKUP_XML(name,url,description)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

