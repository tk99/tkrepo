# -*- coding: utf-8 -*-
#------------------------------------------------------------
# The X Factor International
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.gamerszone'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

ART = xbmc.translatePath(os.path.join(
	'special://home/addons/' + addonID + '/resources/art/'))
    
dan = ART + 'xbox.png'
capt = ART + 'playstation.jpg'
ali = ART + 'ign.png'
spot = ART + 'gamespot.jpg'
nintendo = ART + 'nintendo.png'
EA = ART + 'EA.png'
ubi = ART + 'ubi.jpg'
e3 = ART + 'e3.jpg'

YOUTUBE_CHANNEL_ID1 = "xbox"
YOUTUBE_CHANNEL_ID2 = "PlayStation"
YOUTUBE_CHANNEL_ID3 = "IGNentertainment"
YOUTUBE_CHANNEL_ID4 = "gamespot"
YOUTUBE_CHANNEL_ID5 = "Nintendo"
YOUTUBE_CHANNEL_ID6 = "UCBMvc6jvuTxH6TNo9ThpYjg"
YOUTUBE_CHANNEL_ID7 = "EA"
YOUTUBE_CHANNEL_ID8 = "E3"


# Entry point
def run():
    plugintools.log("gamerszone.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("XFactorInternational.main_list "+repr(params))
        
    plugintools.add_item( 
        #action="", 
        title="Xbox",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail=dan,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="PlayStation",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail=capt,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="IGN",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",
        thumbnail=ali,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="GameSpot",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID4+"/",
        thumbnail=spot,
        folder=True )        
        
    plugintools.add_item( 
        #action="", 
        title="Nintendo",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID5+"/",
        thumbnail=nintendo,
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="Ubisoft",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID6+"/",
        thumbnail=ubi,
        folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Electronic Arts",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail=EA,
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="E3",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail=e3,
        folder=True )
  
       
run()