import xbmc , xbmcaddon , xbmcgui , base64 , xbmcplugin , os , shutil , urllib2 , urllib , re , extract , downloader , time , socket , net , plugintools
net = net . Net ( )
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.wizard2'
Oo0Ooo = xbmcaddon . Addon ( id = OO0o )
O0O0OO0O0O0 = xbmcaddon . Addon ( id = OO0o )
iiiii = xbmc . translatePath ( O0O0OO0O0O0 . getAddonInfo ( 'profile' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
II1 = xbmcgui . Dialog ( )
O00ooooo00 = O0O0OO0O0O0 . getSetting ( 'dsusername' )
I1IiiI = O0O0OO0O0O0 . getSetting ( 'dspassword' )
IIi1IiiiI1Ii = os . path . join ( os . path . join ( iiiii , '' ) , 'ds.lwp' )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' , '' ) )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/' , '' ) )
OOOo0 = "Update Wizard 4.0"
Oooo000o = 'plugin.video.wizard2'
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = [ 'plugin.video.wizard2' , 'repository.tk99' ]
if 28 - 28: Ii11111i * iiI1i1
i1I1ii1II1iII = xbmc . translatePath ( 'special://database' )
oooO0oo0oOOOO = xbmc . translatePath ( 'special://thumbnails' )
if 53 - 53: o0oo0o / Oo + OOo00O0Oo0oO / iIi * ooO00oOoo - O0OOo
II1Iiii1111i = xbmc . translatePath ( os . path . join (
 'special://home/addons/' + Oooo000o + '/resources/art/' ) )
if 25 - 25: OOo000
O0 = II1Iiii1111i + 'fanart.png'
I11i1i11i1I = II1Iiii1111i + 'icon.png'
if 31 - 31: i11iI / Oo0o0ooO0oOOO + I1 - OOoOoo00oo - iiI1i1
# set some default icons
iI1 = II1Iiii1111i + 'k14builds.png'
OoOooOOOO = II1Iiii1111i + 'k16builds.png'
i11iiII = II1Iiii1111i + 'k17builds.png'
I1iiiiI1iII = II1Iiii1111i + 'special.png'
IiIi11i = II1Iiii1111i + 'maint.png'
iIii1I111I11I = II1Iiii1111i + 'cache.png'
OO00OooO0OO = II1Iiii1111i + 'freshstart.png'
iiiIi = II1Iiii1111i + 'packages.png'
IiIIIiI1I1 = II1Iiii1111i + 'android.png'
OoO000 = II1Iiii1111i + 'login.png'
IIiiIiI1 = II1Iiii1111i + 'thumbnails.png'
iiIiIIi = II1Iiii1111i + 'advanced.png'
ooOoo0O = II1Iiii1111i + 'speed.png'
OooO0 = II1Iiii1111i + 'fixes.png'
if 35 - 35: ooO00oOoo % I1 % i11iIiiIii / OOooOOo
if O00ooooo00 == '' or I1IiiI == '' :
 if os . path . exists ( IIi1IiiiI1Ii ) :
  try : os . remove ( IIi1IiiiI1Ii )
  except : pass
 II1 = xbmcgui . Dialog ( )
 Ii11iI1i = II1 . yesno ( 'Update Wizard 4.0' , 'Please enter your username and password' , 'If you dont have these check your emails' , 'Or contact your reseller' , 'Cancel' , 'Login' )
 if Ii11iI1i == 1 :
  Ooo = xbmc . Keyboard ( '' , 'Enter Username' )
  Ooo . doModal ( )
  if ( Ooo . isConfirmed ( ) ) :
   O0o0Oo = Ooo . getText ( )
   Oo00OOOOO = O0o0Oo
   Ooo = xbmc . Keyboard ( '' , 'Enter Password:' )
   Ooo . doModal ( )
   if ( Ooo . isConfirmed ( ) ) :
    O0o0Oo = Ooo . getText ( )
    O0O = O0o0Oo
    O0O0OO0O0O0 . setSetting ( 'dsusername' , Oo00OOOOO )
    O0O0OO0O0O0 . setSetting ( 'dspassword' , O0O )
O00ooooo00 = O0O0OO0O0O0 . getSetting ( 'dsusername' )
I1IiiI = O0O0OO0O0O0 . getSetting ( 'dspassword' )
if 83 - 83: O0OOo + o0O * Oo % iiI1i1 + O0OOo
def Ii1iIIIi1ii ( ) :
 plugintools . log ( str ( o0oo0o0O00OO ( ) ) )
 o0oO ( base64 . b64decode ( I1i1iii ) )
 i1iiI11I = net . http_GET ( base64 . b64decode ( I1i1iii ) )
 if not 'Logged in as' in i1iiI11I . content :
  II1 = xbmcgui . Dialog ( )
  II1 . ok ( 'Update Wizard 4.0' , 'An error has ocurred logging in' , 'Make sure your internet filters are disabled and the username and password entered were correct' , '' )
  quit ( )
 iiii ( 'Kodi 14/15 Builds' , 'url' , 2 , iI1 , O0 , oO0o0O0OOOoo0 )
 iiii ( 'Kodi 16 Builds' , 'url' , 3 , OoOooOOOO , O0 , oO0o0O0OOOoo0 )
 iiii ( 'Kodi 17 Builds' , 'url' , 16 , i11iiII , O0 , oO0o0O0OOOoo0 )
 iiii ( 'Special Builds' , 'url' , 4 , I1iiiiI1iII , O0 , oO0o0O0OOOoo0 )
 iiii ( 'Add-on Fixes' , 'url' , 15 , OooO0 , O0 , oO0o0O0OOOoo0 )
 if o0oo0o0O00OO ( ) == 'android' :
  iiii ( 'Android/Fire TV Apps' , 'url' , 13 , IiIIIiI1I1 , O0 , oO0o0O0OOOoo0 )
 iiii ( 'Maintenance' , 'url' , 6 , IiIi11i , O0 , oO0o0O0OOOoo0 )
 iiii ( 'Advanced Settings' , 'url' , 7 , iiIiIIi , O0 , oO0o0O0OOOoo0 )
 IiIiiI ( 'Login Details' , 'url' , 8 , OoO000 , O0 , oO0o0O0OOOoo0 )
 I1I ( 'movies' , 'MAIN' )
 if 80 - 80: o0oo0o - iiI1i1
 if 87 - 87: iIi / O0OOo - I11i * ooO00oOoo / OOooOOo . i1
def iii11I111 ( ) :
 net . set_cookies ( IIi1IiiiI1Ii )
 OOOO00ooo0Ooo = OOOooOooo00O0 ( base64 . b64decode ( Oo0OO ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoOo00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( OOOO00ooo0Ooo )
 for o0OOoo0OO0OOO , iI1iI1I1i1I , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 in oOOoOo00o :
  IiIiiI ( o0OOoo0OO0OOO , iI1iI1I1i1I , 1 , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 )
 I1I ( 'movies' , 'MAIN' )
 if 51 - 51: o0O * iiI1i1 % Oo * o0O % OOo00O0Oo0oO / OOoOoo00oo
def iIIIIii1 ( ) :
 net . set_cookies ( IIi1IiiiI1Ii )
 OOOO00ooo0Ooo = OOOooOooo00O0 ( base64 . b64decode ( oo000OO00Oo ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoOo00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( OOOO00ooo0Ooo )
 for o0OOoo0OO0OOO , iI1iI1I1i1I , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 in oOOoOo00o :
  IiIiiI ( o0OOoo0OO0OOO , iI1iI1I1i1I , 1 , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 )
 I1I ( 'movies' , 'MAIN' )
 if 51 - 51: Oo0o0ooO0oOOO * Oo + O0OOo + iiI1i1
def o0O0O00 ( ) :
 net . set_cookies ( IIi1IiiiI1Ii )
 OOOO00ooo0Ooo = OOOooOooo00O0 ( base64 . b64decode ( o000o ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoOo00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( OOOO00ooo0Ooo )
 for o0OOoo0OO0OOO , iI1iI1I1i1I , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 in oOOoOo00o :
  IiIiiI ( o0OOoo0OO0OOO , iI1iI1I1i1I , 1 , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 )
 I1I ( 'movies' , 'MAIN' )
 if 7 - 7: OOoOoo00oo * iiI1i1 % iIi . Oo0o0ooO0oOOO
def Ii1iIiII1ii1 ( ) :
 net . set_cookies ( IIi1IiiiI1Ii )
 OOOO00ooo0Ooo = OOOooOooo00O0 ( base64 . b64decode ( ooOooo000oOO ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoOo00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( OOOO00ooo0Ooo )
 for o0OOoo0OO0OOO , iI1iI1I1i1I , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 in oOOoOo00o :
  IiIiiI ( o0OOoo0OO0OOO , iI1iI1I1i1I , 1 , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 )
 I1I ( 'movies' , 'MAIN' )
 if 59 - 59: o0O + OOooOOo * o0oo0o + I11i
Oo0OO = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzEzLw=='
if 58 - 58: o0O * ooO00oOoo * OOo00O0Oo0oO / ooO00oOoo
def oO0o0OOOO ( ) :
 net . set_cookies ( IIi1IiiiI1Ii )
 OOOO00ooo0Ooo = OOOooOooo00O0 ( base64 . b64decode ( O0O0OoOO0 ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoOo00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( OOOO00ooo0Ooo )
 for o0OOoo0OO0OOO , iI1iI1I1i1I , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 in oOOoOo00o :
  IiIiiI ( o0OOoo0OO0OOO , iI1iI1I1i1I , 1 , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 )
 I1I ( 'movies' , 'MAIN' )
 if 10 - 10: OOooOOo % ii1IiI1i
def O00o0O00 ( ) :
 net . set_cookies ( IIi1IiiiI1Ii )
 OOOO00ooo0Ooo = OOOooOooo00O0 ( base64 . b64decode ( ii111111I1iII ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
 oOOoOo00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( OOOO00ooo0Ooo )
 for o0OOoo0OO0OOO , iI1iI1I1i1I , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 in oOOoOo00o :
  IiIiiI ( o0OOoo0OO0OOO , iI1iI1I1i1I , 1 , iIi11Ii1 , Ii11iII1 , oO0o0O0OOOoo0 )
 I1I ( 'movies' , 'MAIN' )
 if 68 - 68: i11iI - ii1IiI1i * i11iIiiIii / OOo00O0Oo0oO * I1
def i1iIi1iIi1i ( ) :
 net . set_cookies ( IIi1IiiiI1Ii )
 OOOO00ooo0Ooo = OOOooOooo00O0 ( base64 . b64decode ( I1I1iIiII1 ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' )
 oOOoOo00o = re . compile ( 'name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"' ) . findall ( OOOO00ooo0Ooo )
 for o0OOoo0OO0OOO , iI1iI1I1i1I , ooo0OO , Ii11iII1 in oOOoOo00o :
  IiIiiI ( o0OOoo0OO0OOO , iI1iI1I1i1I , 14 , ooo0OO , Ii11iII1 )
 I1I ( 'movies' , 'MAIN' )
 if 4 - 4: OOoOoo00oo + i1 * ooO00oOoo
def OOoo0O ( name , url ) :
 Oo0ooOo0o = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
 Ii1i1 = xbmcgui . DialogProgress ( )
 Ii1i1 . create ( "Update Wizard 4.0" , "Downloading the Android application to your device" , "[COLOR=red]This will only install on Android and Fire TV devices[/COLOR]" , 'Please Wait' )
 iiIii = os . path . join ( Oo0ooOo0o , name + '.zip' )
 try :
  os . remove ( iiIii )
 except :
  pass
 downloader . download ( url , iiIii , Ii1i1 )
 ooo0O = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 time . sleep ( 2 )
 Ii1i1 . close ( )
 II1 = xbmcgui . Dialog ( )
 II1 . ok ( "Update Wizard 4.0" , "Android application downloaded successfully" , "Press OK and follow the install process to complete the installation" )
 xbmc . executebuiltin ( 'StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:' + iiIii + '")' )
 if 75 - 75: Oo % Oo . I1
I1I1iIiII1 = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzE3Lw=='
if 5 - 5: Oo * OOoOoo00oo + o0oo0o . ooO00oOoo + o0oo0o
def oO ( params ) :
 plugintools . log ( "freshstart.main_list " + repr ( params ) ) ; iIi1IIIi1 = plugintools . message_yes_no ( OOOo0 , "Do you wish to clear the Kodi userdata whilst leaving Update Wizard 4.0 installed?" , "[COLOR red]DO NOT PRESS ANY BUTTONS AFTER SELECTING YES UNTIL PROMPTED![/COLOR]" )
 if iIi1IIIi1 :
  O0oOoOOOoOO = xbmcaddon . Addon ( id = Oooo000o ) . getAddonInfo ( 'path' ) ; O0oOoOOOoOO = xbmc . translatePath ( O0oOoOOOoOO ) ;
  ii1ii11IIIiiI = os . path . join ( O0oOoOOOoOO , ".." , ".." ) ; ii1ii11IIIiiI = os . path . abspath ( ii1ii11IIIiiI ) ; plugintools . log ( "freshstart.main_list xbmcPath=" + ii1ii11IIIiiI ) ; O00OOOoOoo0O = False
  try :
   for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( ii1ii11IIIiiI , topdown = True ) :
    oo0OOo [ : ] = [ IiIIIi1iIi for IiIIIi1iIi in oo0OOo if IiIIIi1iIi not in IiII ]
    for o0OOoo0OO0OOO in ooOOO00Ooo :
     try : os . remove ( os . path . join ( O000OOo00oo , o0OOoo0OO0OOO ) )
     except :
      if o0OOoo0OO0OOO not in [ "Addons15.db" , "MyVideos75.db" , "Textures13.db" , "xbmc.log" ] : O00OOOoOoo0O = True
      plugintools . log ( "Error removing " + O000OOo00oo + " " + o0OOoo0OO0OOO )
    for o0OOoo0OO0OOO in oo0OOo :
     try : os . rmdir ( os . path . join ( O000OOo00oo , o0OOoo0OO0OOO ) )
     except :
      if o0OOoo0OO0OOO not in [ "Database" , "userdata" ] : O00OOOoOoo0O = True
      plugintools . log ( "Error removing " + O000OOo00oo + " " + o0OOoo0OO0OOO )
   if not O00OOOoOoo0O : plugintools . log ( "freshstart.main_list All user files removed, you now have a clean install" ) ; plugintools . message ( OOOo0 , "Process is complete, you've got a clean install!" , "Select yes to force close on the next screen in order for the changes to be applied. Update wizard can then be found by selecting the programs menu bar in Kodi" )
   else : plugintools . log ( "freshstart.main_list User files partially removed" ) ; plugintools . message ( OOOo0 , "Process is complete, you've got a clean install!" , "Select yes to force close on the next screen in order for the changes to be applied. Update wizard can then be found by selecting the programs menu bar in Kodi" )
  except : plugintools . message ( OOOo0 , "Problem found" , "Your settings has not been changed" ) ; import traceback ; plugintools . log ( traceback . format_exc ( ) ) ; plugintools . log ( "freshstart.main_list NOT removed" )
  ooOOoooooo ( )
  if 1 - 1: Ii11111i / Oo % i11iI * Oo0o0ooO0oOOO . i11iIiiIii
o000o = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzE5Lw=='
if 2 - 2: OOo00O0Oo0oO * O0OOo - ii1IiI1i + IiiIII111iI . iIi % i11iI
def ooOOOoOooOoO ( ) :
 IiIiiI ( 'Factory Reset Kodi' , 'url' , 5 , OO00OooO0OO , 'Reset your Kodi to its default settings, this will remove all addons, settings and skins' )
 IiIiiI ( 'Delete Cache' , 'url' , 9 , iIii1I111I11I , 'Delete cache files' )
 IiIiiI ( 'Delete Package files' , 'url' , 10 , iiiIi , 'Delete the Package Files' )
 IiIiiI ( 'Delete Thumbnails' , 'url' , 11 , IIiiIiI1 , 'Delete the thumbnail files' )
 IiIiiI ( 'Speed Test' , 'url' , 12 , ooOoo0O , 'Speed Test' )
 I1I ( 'movies' , 'MAIN' )
 if 91 - 91: i11iI % I11i % ii1IiI1i
def IIi1I11I1II ( ) :
 plugintools . open_settings_dialog ( )
 if 63 - 63: OOooOOo - iiI1i1 . o0O / Oo . o0oo0o / i1
O0O0OoOO0 = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzE4Lw=='
if 84 - 84: Oo0o0ooO0oOOO
def OOO00O0O ( url ) :
 print '###' + OOOo0 + ' - DELETING PACKAGES###'
 iii = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , '' ) )
 try :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( iii ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 41 - 41: OOo000 - i1 - i1
   if 68 - 68: ooO00oOoo % I1
   if oOooOOOoOo > 0 :
    if 88 - 88: ii1IiI1i - OOoOoo00oo + ooO00oOoo
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete Package Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 40 - 40: IiiIII111iI * OOo000 + ooO00oOoo % i11iI
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
     II1 = xbmcgui . Dialog ( )
     II1 . ok ( OOOo0 , "Deleting Packages all done" )
    else :
     pass
   else :
    II1 = xbmcgui . Dialog ( )
    II1 . ok ( OOOo0 , "No Packages to Delete" )
 except :
  II1 = xbmcgui . Dialog ( )
  II1 . ok ( OOOo0 , "Error Deleting Packages" )
 return
 if 49 - 49: i1 . i11iI
def I1iI1iIi111i ( url ) :
 print '############################################################	   DELETING STANDARD CACHE			 ###############################################################'
 iiIi1IIi1I = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 if os . path . exists ( iiIi1IIi1I ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( iiIi1IIi1I ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 84 - 84: OOoOoo00oo * o0O + Ii11111i
   if 53 - 53: i11iI % o0O . Oo0o0ooO0oOOO - ii1IiI1i - Oo0o0ooO0oOOO * o0O
   if oOooOOOoOo > 0 :
    if 77 - 77: ii1IiI1i * iiI1i1
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete KODI Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 95 - 95: IiiIII111iI + i11iIiiIii
     for OOOOOoo0 in ooOOO00Ooo :
      try :
       os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
      except :
       pass
     for IiIIIi1iIi in oo0OOo :
      try :
       shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      except :
       pass
       if 6 - 6: OOoOoo00oo / i11iIiiIii + i11iI * iIi
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  o00o0 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 45 - 45: i1
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( o00o0 ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 26 - 26: O0OOo - ii1IiI1i - IiiIII111iI / iiI1i1 . o0oo0o % ii1IiI1i
   if oOooOOOoOo > 0 :
    if 91 - 91: Oo . ii1IiI1i / iIi + I11i
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete ATV2 Cache Files" , str ( oOooOOOoOo ) + " files found in 'Other'" , "Do you want to delete them?" ) :
     if 42 - 42: OOoOoo00oo . Oo . OOoOoo00oo - OOo00O0Oo0oO
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 40 - 40: OOoOoo00oo - i11iIiiIii / OOo000
   else :
    pass
  I11iiI1i1 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 47 - 47: i11iI - OOo000 . o0O + OOooOOo . i11iIiiIii
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( I11iiI1i1 ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 94 - 94: Oo * OOo000 / Ii11111i / OOo000
   if oOooOOOoOo > 0 :
    if 87 - 87: Ii11111i . Oo0o0ooO0oOOO
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete ATV2 Cache Files" , str ( oOooOOOoOo ) + " files found in 'LocalAndRental'" , "Do you want to delete them?" ) :
     if 75 - 75: OOoOoo00oo + o0oo0o + Oo * O0OOo % iIi . i11iI
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 55 - 55: ooO00oOoo . IiiIII111iI
   else :
    pass
    if 61 - 61: Ii11111i % Oo0o0ooO0oOOO . Ii11111i
    if 100 - 100: I1 * i1
    if 64 - 64: ooO00oOoo % ii1IiI1i * iIi
    if 79 - 79: i1
 oOO00O = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 if os . path . exists ( oOO00O ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( oOO00O ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 77 - 77: Ii11111i - I11i - O0OOo . o0oo0o
   if 39 - 39: o0O / OOoOoo00oo + I1 / o0oo0o
   if oOooOOOoOo > 0 :
    if 13 - 13: Oo0o0ooO0oOOO + i1 + i11iI % IiiIII111iI / Oo . Oo0o0ooO0oOOO
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete WTF Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 86 - 86: iIi * Oo % I11i . OOo000 . i11iIiiIii
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 56 - 56: OOo00O0Oo0oO % i1 - IiiIII111iI
   else :
    pass
    if 100 - 100: OOo000 - i1 % iIi * ooO00oOoo + IiiIII111iI
    if 88 - 88: OOooOOo - iiI1i1 * i1 * OOooOOo . OOooOOo
 I111iI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.4od/cache' ) , '' )
 if os . path . exists ( I111iI ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( I111iI ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 56 - 56: IiiIII111iI
   if 54 - 54: I1 / ooO00oOoo . iIi % i11iI
   if oOooOOOoOo > 0 :
    if 57 - 57: i11iIiiIii . OOo00O0Oo0oO - OOo000 - iIi + o0oo0o
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete 4oD Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 63 - 63: o0oo0o * i11iI
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 69 - 69: i1 . iiI1i1
   else :
    pass
    if 49 - 49: IiiIII111iI - O0OOo
    if 74 - 74: ii1IiI1i * OOo00O0Oo0oO + o0oo0o / I11i / o0O . Ii11111i
 oooOo0OOOoo0 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 if os . path . exists ( oooOo0OOOoo0 ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( oooOo0OOOoo0 ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 51 - 51: Ii11111i / o0oo0o . ooO00oOoo * Oo + iiI1i1 * Oo0o0ooO0oOOO
   if 73 - 73: iiI1i1 + OOooOOo - i1 - OOo000 - o0O
   if oOooOOOoOo > 0 :
    if 99 - 99: OOoOoo00oo . OOo000 + I1 + OOooOOo % Oo
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete BBC iPlayer Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 51 - 51: ii1IiI1i
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 34 - 34: iIi + IiiIII111iI - iIi
   else :
    pass
    if 17 - 17: o0O % i11iI + O0OOo - i11iI / ooO00oOoo + OOoOoo00oo
    if 59 - 59: ooO00oOoo % o0oo0o . OOo000 * OOo00O0Oo0oO % O0OOo
    if 59 - 59: iIi - i11iI
 I1ii1I1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 if os . path . exists ( I1ii1I1 ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( I1ii1I1 ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 93 - 93: i1 % I11i . ooO00oOoo / IiiIII111iI - I1 / IiiIII111iI
   if 36 - 36: iIi % iIi % I11i / I11i - OOoOoo00oo
   if oOooOOOoOo > 0 :
    if 30 - 30: O0OOo / IiiIII111iI
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete Simple Downloader Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 35 - 35: o0O % ooO00oOoo . OOoOoo00oo + OOoOoo00oo % o0O % o0O
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 72 - 72: o0O + I11i + Oo
   else :
    pass
    if 94 - 94: iIi . I11i - Oo % i1 - iiI1i1
    if 72 - 72: OOo000
 II11Ii1iI1iII = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 if os . path . exists ( II11Ii1iI1iII ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( II11Ii1iI1iII ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 73 - 73: OOooOOo * OOooOOo * OOoOoo00oo * o0oo0o + OOoOoo00oo * I1
   if 88 - 88: OOo00O0Oo0oO
   if oOooOOOoOo > 0 :
    if 11 - 11: OOoOoo00oo / o0oo0o - Oo0o0ooO0oOOO * OOooOOo + OOooOOo . o0oo0o
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete ITV Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 26 - 26: OOo000 % OOo00O0Oo0oO
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 76 - 76: Oo0o0ooO0oOOO * i11iI
   else :
    pass
    if 52 - 52: ooO00oOoo
    if 19 - 19: IiiIII111iI
 i11i = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.movies4me/cache' ) , '' )
 if os . path . exists ( II11Ii1iI1iII ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( i11i ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 73 - 73: ooO00oOoo
   if 70 - 70: ii1IiI1i
   if oOooOOOoOo > 0 :
    if 31 - 31: Oo0o0ooO0oOOO - IiiIII111iI % ii1IiI1i
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete Movies4me Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 92 - 92: I11i - ii1IiI1i
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 16 - 16: iiI1i1 - o0oo0o - ooO00oOoo - I11i / OOo000
   else :
    pass
    if 88 - 88: iiI1i1
    if 71 - 71: OOo00O0Oo0oO
 IIiiIiiI = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 if os . path . exists ( II11Ii1iI1iII ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( IIiiIiiI ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 10 - 10: o0oo0o % o0oo0o - o0oo0o . i11iI
   if 73 - 73: O0OOo % i11iIiiIii - IiiIII111iI
   if oOooOOOoOo > 0 :
    if 7 - 7: i1 * i11iIiiIii * OOo000 + OOoOoo00oo % iiI1i1 - OOoOoo00oo
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete Phoenix Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 39 - 39: Ii11111i * ooO00oOoo % ooO00oOoo - OOooOOo + Oo - O0OOo
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 23 - 23: i11iIiiIii
   else :
    pass
    if 30 - 30: Oo - I11i % o0O + O0OOo * ii1IiI1i
    if 81 - 81: Oo0o0ooO0oOOO % I11i . ii1IiI1i
 Ii1Iii1iIi = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.spotitube/cache' ) , '' )
 if os . path . exists ( II11Ii1iI1iII ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( Ii1Iii1iIi ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 82 - 82: OOo00O0Oo0oO / IiiIII111iI % ii1IiI1i / I11i - IiiIII111iI
   if 7 - 7: I1 * iiI1i1 - OOoOoo00oo + ooO00oOoo * IiiIII111iI % iiI1i1
   if oOooOOOoOo > 0 :
    if 15 - 15: o0oo0o % IiiIII111iI * O0OOo
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete YouTube Music Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 81 - 81: OOoOoo00oo - ii1IiI1i - I11i / I1 - i1 * O0OOo
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 20 - 20: iIi % Oo0o0ooO0oOOO
   else :
    pass
    if 19 - 19: OOo00O0Oo0oO % Oo0o0ooO0oOOO + OOoOoo00oo / I1 . OOoOoo00oo
    if 12 - 12: I11i + I11i - OOo00O0Oo0oO * Ii11111i % Ii11111i - o0O
 o0OOOOooo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.supercartoons/cache' ) , '' )
 if os . path . exists ( II11Ii1iI1iII ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( o0OOOOooo ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 94 - 94: OOooOOo + Ii11111i / o0oo0o * ooO00oOoo
   if 69 - 69: OOoOoo00oo % iIi
   if oOooOOOoOo > 0 :
    if 50 - 50: OOooOOo % O0OOo
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete SuperCartoons Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 49 - 49: iIi - i11iIiiIii . I1 * OOo000 % i11iI + I11i
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 71 - 71: Oo
   else :
    pass
    if 38 - 38: iIi % o0oo0o + OOo00O0Oo0oO . i11iIiiIii
    if 53 - 53: i11iIiiIii * i11iI
 OooooO0oOOOO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.tvonline.cc/cache' ) , '' )
 if os . path . exists ( II11Ii1iI1iII ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( OooooO0oOOOO ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 100 - 100: i11iI % ooO00oOoo
   if 86 - 86: Ii11111i . i1 - OOooOOo . iiI1i1 + OOo000
   if oOooOOOoOo > 0 :
    if 57 - 57: Oo . I11i . Oo0o0ooO0oOOO * i11iIiiIii + I1 . Oo0o0ooO0oOOO
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete TVonline Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 57 - 57: I1
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 32 - 32: OOo000 - Ii11111i % OOooOOo . i11iI / Oo0o0ooO0oOOO + IiiIII111iI
   else :
    pass
    if 76 - 76: OOoOoo00oo
    if 73 - 73: i1 * i11iI + OOo000 + OOoOoo00oo
 Ii = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.youtube/kodion' ) , '' )
 if os . path . exists ( II11Ii1iI1iII ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( Ii ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 100 - 100: I1 + ooO00oOoo + ooO00oOoo
   if 9 - 9: O0OOo % OOooOOo . iIi % O0OOo
   if oOooOOOoOo > 0 :
    if 32 - 32: i11iIiiIii
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete YouTube Cache Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 31 - 31: ii1IiI1i / iiI1i1 / OOo00O0Oo0oO
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 41 - 41: Ii11111i
   else :
    pass
    if 10 - 10: Ii11111i / Ii11111i / I1 . I1
    if 98 - 98: Ii11111i / IiiIII111iI . i1 + iiI1i1
 ii = os . path . join ( xbmc . translatePath ( 'special://home/temp' ) , '' )
 if os . path . exists ( ii ) == True :
  for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( ii ) :
   oOooOOOoOo = 0
   oOooOOOoOo += len ( ooOOO00Ooo )
   if 25 - 25: OOooOOo - IiiIII111iI . IiiIII111iI * iIi
   if 81 - 81: i11iI + Oo0o0ooO0oOOO
   if oOooOOOoOo > 0 :
    if 98 - 98: IiiIII111iI
    II1 = xbmcgui . Dialog ( )
    if II1 . yesno ( "Delete Temp Files" , str ( oOooOOOoOo ) + " files found" , "Do you want to delete them?" ) :
     if 95 - 95: OOoOoo00oo / OOoOoo00oo
     for OOOOOoo0 in ooOOO00Ooo :
      os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
     for IiIIIi1iIi in oo0OOo :
      shutil . rmtree ( os . path . join ( O000OOo00oo , IiIIIi1iIi ) )
      if 30 - 30: OOo00O0Oo0oO + Ii11111i / Ii11111i % OOo00O0Oo0oO . OOo00O0Oo0oO
      if 55 - 55: OOoOoo00oo - O0OOo + o0O + i11iI % OOo000
      if 41 - 41: I11i - O0OOo - OOo000
 III11I1 = xbmc . translatePath ( 'special://masterprofile/addon_data/plugin.video.exodus' )
 II1 = xbmcgui . Dialog ( )
 try :
  if II1 . yesno ( "Delete Exodus Cache Files" , "Do you want to delete cache" ) :
   IIi1IIIi = os . path . join ( III11I1 , "cache.db" )
   os . unlink ( IIi1IIIi )
   if 99 - 99: OOo000 + iiI1i1 * o0O . Oo - OOo00O0Oo0oO
 except :
  pass
  if 58 - 58: OOo000 + Oo - IiiIII111iI
 II1 = xbmcgui . Dialog ( )
 II1 . ok ( "Update Wizard 4.0" , "Finished Deleting Cache Files" )
 if 3 - 3: iiI1i1
def oooOoOOO0oo0o ( url ) :
 if 85 - 85: OOooOOo % I11i * OOooOOo / OOo00O0Oo0oO
 if plugintools . message_yes_no ( OOOo0 , "Are you sure you want to delete all thumbnails?" ) :
  if os . path . exists ( oooO0oo0oOOOO ) == True :
   for O000OOo00oo , oo0OOo , ooOOO00Ooo in os . walk ( oooO0oo0oOOOO ) :
    oOooOOOoOo = 0
    oOooOOOoOo += len ( ooOOO00Ooo )
    if oOooOOOoOo > 0 :
     for OOOOOoo0 in ooOOO00Ooo :
      try :
       os . unlink ( os . path . join ( O000OOo00oo , OOOOOoo0 ) )
      except :
       pass
   plugintools . message ( OOOo0 , "All thumbnails removed" , "Press yes on the next screen to force close kodi and rebuild the thumbnail library" )
 ooOOoooooo ( )
 if 96 - 96: OOooOOo + iIi
oo000OO00Oo = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzE0Lw=='
if 44 - 44: iIi
def OOOooOooo00O0 ( url ) :
 I1i11i = urllib2 . Request ( url )
 I1i11i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 i1iiI11I = urllib2 . urlopen ( I1i11i )
 OOOO00ooo0Ooo = i1iiI11I . read ( )
 i1iiI11I . close ( )
 return OOOO00ooo0Ooo
 if 11 - 11: IiiIII111iI / o0O + Oo * OOo00O0Oo0oO - OOo00O0Oo0oO - IiiIII111iI
def O0oOooooo0O ( name , url , description ) :
 Oo0ooOo0o = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
 Ii1i1 = xbmcgui . DialogProgress ( )
 Ii1i1 . create ( "Update Wizard 4.0" , "Downloading configuration files" , '' , 'Please Wait' )
 iiIii = os . path . join ( Oo0ooOo0o , name + '.zip' )
 try :
  os . remove ( iiIii )
 except :
  pass
 downloader . download ( url , iiIii , Ii1i1 )
 ooo0O = xbmc . translatePath ( os . path . join ( 'special://' , 'home' ) )
 time . sleep ( 2 )
 Ii1i1 . update ( 0 , "" , "Configuring the addons and custom menu" )
 extract . all ( iiIii , ooo0O , Ii1i1 )
 II1 = xbmcgui . Dialog ( )
 II1 . ok ( "Update Wizard 4.0" , "Almost Finished Configuring the build" , "[COLOR red]Press OK to Force Close, if Force Close fails, disconnect the power as normal[/COLOR]" )
 ooOOoooooo ( )
 if 42 - 42: Ii11111i
I1i1iii = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvbWVtYmVy'
if 19 - 19: iIi % OOo00O0Oo0oO * ii1IiI1i + IiiIII111iI
def o0oO ( srDomain ) :
 iii11I = net . http_GET ( srDomain ) . content
 I1Iii1 = re . findall ( r'<input type="hidden" name="(.+?)" value="(.+?)" />' , iii11I , re . I )
 iiI11Iii = { }
 iiI11Iii [ 'amember_login' ] = O00ooooo00
 iiI11Iii [ 'amember_pass' ] = I1IiiI
 for o0OOoo0OO0OOO , O0o0O0 in I1Iii1 :
  iiI11Iii [ o0OOoo0OO0OOO ] = O0o0O0
 net . http_GET ( base64 . b64decode ( I1i1iii ) )
 net . http_POST ( base64 . b64decode ( I1i1iii ) , iiI11Iii )
 net . save_cookies ( IIi1IiiiI1Ii )
 net . set_cookies ( IIi1IiiiI1Ii )
 if 11 - 11: o0O % iiI1i1 * i11iI + OOoOoo00oo + OOo000
def IiIiiI ( name , url , mode , iconimage , fanart , description = '' ) :
 II1Iiiiii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description )
 ii1ii111 = True
 I111i1i1111 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I111i1i1111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 I111i1i1111 . setProperty ( 'fanart_image' , fanart )
 ii1ii111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iiiiii , listitem = I111i1i1111 , isFolder = False )
 return ii1ii111
 if 49 - 49: iiI1i1 / iIi + i1 * Oo
def iiii ( name , url , mode , iconimage , fanart , description = '' ) :
 II1Iiiiii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description )
 ii1ii111 = True
 I111i1i1111 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I111i1i1111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 I111i1i1111 . setProperty ( 'fanart_image' , fanart )
 ii1ii111 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1Iiiiii , listitem = I111i1i1111 , isFolder = True )
 return ii1ii111
 if 28 - 28: OOoOoo00oo + i11iIiiIii / O0OOo % o0oo0o % Ii11111i - i1
def I1I ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
 if Oo0Ooo . getSetting ( 'auto-view' ) == 'true' :
  xbmc . executebuiltin ( "Container.SetViewMode(%s)" % Oo0Ooo . getSetting ( viewType ) )
  if 54 - 54: I11i + o0O
oOOO0oo0 = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzEyLw=='
if 46 - 46: Oo0o0ooO0oOOO
if 45 - 45: OOoOoo00oo
def IIi ( ) :
 ooO0oOo0o = [ ]
 OO = sys . argv [ 2 ]
 if len ( OO ) >= 2 :
  ii111IiiI1 = sys . argv [ 2 ]
  ii11i1iIiII1 = ii111IiiI1 . replace ( '?' , '' )
  if ( ii111IiiI1 [ len ( ii111IiiI1 ) - 1 ] == '/' ) :
   ii111IiiI1 = ii111IiiI1 [ 0 : len ( ii111IiiI1 ) - 2 ]
  o00oo0 = ii11i1iIiII1 . split ( '&' )
  ooO0oOo0o = { }
  for oooooOOO000Oo in range ( len ( o00oo0 ) ) :
   Ooo00OoOOO = { }
   Ooo00OoOOO = o00oo0 [ oooooOOO000Oo ] . split ( '=' )
   if ( len ( Ooo00OoOOO ) ) == 2 :
    ooO0oOo0o [ Ooo00OoOOO [ 0 ] ] = Ooo00OoOOO [ 1 ]
    if 98 - 98: ii1IiI1i * OOo00O0Oo0oO * ooO00oOoo + OOoOoo00oo % i11iIiiIii % i1
 return ooO0oOo0o
 if 27 - 27: i1
ii111111I1iII = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzE2Lw=='
if 79 - 79: Oo - O0OOo + Oo . iIi
def ooOOoooooo ( ) :
 ii1III11 = plugintools . message_yes_no ( 'Force Close Kodi' , 'You are about to close Kodi' , 'Would you like to continue?' )
 if ii1III11 == 0 :
  return
 elif ii1III11 == 1 :
  pass
 I1iiIIIi11 = o0oo0o0O00OO ( )
 print "Platform: " + str ( I1iiIIIi11 )
 if 12 - 12: OOooOOo % Oo * O0OOo % ii1IiI1i / OOo000
 try :
  os . _exit ( 1 )
 except :
  pass
  if 27 - 27: i11iIiiIii % o0O % O0OOo . i1 - Ii11111i + o0oo0o
 if I1iiIIIi11 == 'osx' :
  print "############   try osx force close  #################"
  try :
   os . system ( 'killall -9 XBMC' )
  except :
   pass
  try :
   os . system ( 'killall -9 Kodi' )
  except :
   pass
  plugintools . message ( OOOo0 , "Force Close has failed, to complete the update" , "Press 'OK' then disconnect the power cable as normal [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu." , '' )
 elif I1iiIIIi11 == 'linux' :
  print "############   try linux force close  #################"
  try :
   os . system ( 'killall XBMC' )
  except :
   pass
  try :
   os . system ( 'killall Kodi' )
  except :
   pass
  try :
   os . system ( 'killall -9 xbmc.bin' )
  except :
   pass
  try :
   os . system ( 'killall -9 kodi.bin' )
  except :
   pass
  plugintools . message ( OOOo0 , "If you\'re seeing this message it means the force close" , "was unsuccessful. Please force close Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu." , '' )
 elif I1iiIIIi11 == 'android' :
  if 57 - 57: ii1IiI1i / O0OOo - I11i
  print "############   try android force close  #################"
  if 51 - 51: Oo0o0ooO0oOOO
  try :
   os . _exit ( 1 )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.kodi' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop org.xbmc' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop com.semperpax.spmc16' )
  except :
   pass
  try :
   os . system ( 'adb shell am force-stop com.spmc16' )
  except :
   pass
  time . sleep ( 5 )
  plugintools . message ( OOOo0 , "[COLOR=yellow][B] Force Close has failed, to complete the update[/COLOR][/B]" , "Press 'OK' then disconnect the power cable as normal" )
 elif I1iiIIIi11 == 'windows' :
  print "############   try windows force close  #################"
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill XBMC.exe' )
  except :
   pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill Kodi.exe' )
  except :
   pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im Kodi.exe /f' )
  except :
   pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im XBMC.exe /f' )
  except :
   pass
  plugintools . message ( OOOo0 , "[COLOR=red][B]WARNING  !!![/COLOR][/B]" , "If you\'re seeing this message it means the force close" , "was unsuccessful. Please force close Kodi [COLOR=lime]DO NOT[/COLOR] exit this menu." , "press CTRL-ALT-DEL, start task manager and end the Kodi process" )
 else :
  print "############   try atv force close  #################"
  try :
   os . system ( 'killall AppleTV' )
  except :
   pass
  print "############   try raspbmc force close  #################"
  try :
   os . system ( 'sudo initctl stop kodi' )
  except :
   pass
  try :
   os . system ( 'sudo initctl stop xbmc' )
  except :
   pass
  plugintools . message ( OOOo0 , "If you\'re seeing this message it means the force close" , "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu." , "iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo." )
  if 25 - 25: OOooOOo + Oo0o0ooO0oOOO * OOo00O0Oo0oO
ooOooo000oOO = 'aHR0cDovL3Rla25va2F0LmNvLnVrL2FtZW1iZXIvY29udGVudC9mL2lkLzE1Lw=='
if 92 - 92: IiiIII111iI + O0OOo + i1 / Oo + I1
def o0oo0o0O00OO ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 18 - 18: OOoOoo00oo * o0oo0o . i11iI / OOo00O0Oo0oO / i11iIiiIii
ii111IiiI1 = IIi ( ) ; iI1iI1I1i1I = None ; o0OOoo0OO0OOO = None ; IIIII = None ; iIi11Ii1 = None ; oO0o0O0OOOoo0 = None
try : iI1iI1I1i1I = urllib . unquote_plus ( ii111IiiI1 [ "url" ] )
except : pass
try : o0OOoo0OO0OOO = urllib . unquote_plus ( ii111IiiI1 [ "name" ] )
except : pass
try : iIi11Ii1 = urllib . unquote_plus ( ii111IiiI1 [ "iconimage" ] )
except : pass
try : IIIII = int ( ii111IiiI1 [ "mode" ] )
except : pass
try : oO0o0O0OOOoo0 = urllib . unquote_plus ( ii111IiiI1 [ "description" ] )
except : pass
if 78 - 78: OOo000 * I11i
if IIIII == None or iI1iI1I1i1I == None or len ( iI1iI1I1i1I ) < 1 : Ii1iIIIi1ii ( )
elif IIIII == 1 : O0oOooooo0O ( o0OOoo0OO0OOO , iI1iI1I1i1I , oO0o0O0OOOoo0 )
elif IIIII == 2 : iii11I111 ( )
elif IIIII == 3 : iIIIIii1 ( )
elif IIIII == 4 : Ii1iIiII1ii1 ( )
elif IIIII == 5 : oO ( ii111IiiI1 )
elif IIIII == 6 : ooOOOoOooOoO ( )
elif IIIII == 7 : O00o0O00 ( )
elif IIIII == 8 : IIi1I11I1II ( )
elif IIIII == 9 : I1iI1iIi111i ( iI1iI1I1i1I )
elif IIIII == 10 : OOO00O0O ( iI1iI1I1i1I )
elif IIIII == 11 : oooOoOOO0oo0o ( iI1iI1I1i1I )
elif IIIII == 12 : import speedtest
elif IIIII == 13 : i1iIi1iIi1i ( )
elif IIIII == 14 : OOoo0O ( o0OOoo0OO0OOO , iI1iI1I1i1I )
elif IIIII == 15 : oO0o0OOOO ( )
elif IIIII == 16 : o0O0O00 ( )
if 1 - 1: IiiIII111iI / Oo0o0ooO0oOOO * OOoOoo00oo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if 1 - 1: O0OOo * Oo . o0oo0o / i1
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3